# coding=utf-8
import re
import requests  # 导入库


def dowmload(html, keyword):
    pic_url = re.findall('"objURL":"(.*?)",', html, re.S)  # 把获取到的网址内容里以”objURL“开头的网址获取
    i = 0  # 初始化计数变量
    print '找到关键词:'+keyword+'的图片，现在开始下载图片...'
    for each in pic_url:  # 循环获取到的网址
        print '正在下载第'+str(i+1)+'张图片，图片地址:'+str(each)
        try:
            pic = requests.get(each, timeout=10)  # 获取图片的内容
        except requests.exceptions.ConnectionError:  # 如果获取失败，就执行
            print '【错误】当前图片无法下载'
            continue
        string = 'img\\'+keyword+'_'+str(i) + '.jpg'  # 设置图片的保存地址和保存名字
        fp = open(string.decode('utf-8').encode('cp936'), 'wb')  # 以编码形式打开设置的保存地址，然后以二进制写图片
        print pic.content
        fp.write(pic.content)  # 把图片的二进制打包成jpg格式的图片
        fp.close()  # 关闭文件
        i += 1  # 计数器加1


if __name__ == '__main__':
    word = raw_input("请输入需要搜索的图片：")  # 输入内容的提示
    # 需要爬去的网址
    url = 'http://image.baidu.com/search/flip?tn=baiduimage&ie=utf-8&word='+word+'&ct=201326592&v=flip'
    print url  # 打印网址
    result = requests.get(url)  # 访问网址
    print result.text  # 打印获取到的网址的内容
    dowmload(result.text, word)  # 把相应参数传输给下载的子程序
