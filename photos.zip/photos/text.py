# coding=utf-8
i = 10

text = "今天"+ str(i) +"号"
texts = "今天%s号" % i
print text, texts