#!/usr/bin/env python
# _*_coding:utf-8_*_
import flicklib
import time

some_value = 5000


@flicklib.move()
def move(x, y, z):
    global xyztxt
    xyztxt = '{:5.3f} {:5.3f} {:5.3f}'.format(x,y,z)


@flicklib.flick()
def flick(start, finish):
    global flicktxt
    flicktxt = 'FLICK-' + start[0].upper() + finish[0].upper()


@flicklib.airwheel()
def spinny(delta):
    global some_value
    global airwheeltxt
    some_value += delta
    if some_value < 0:
        some_value = 0
    if some_value > 10000:
        some_value = 10000
    airwheeltxt = str(some_value/100)


@flicklib.double_tap()
def doubletap(position):
    global doubletaptxt
    doubletaptxt = position


@flicklib.tap()
def tap(position):
    global taptxt
    taptxt = position


@flicklib.touch()
def touch(position):
    global touchtxt
    touchtxt = position


def main():
    global xyztxt, direction_msg, touch_msg
    global flicktxt
    global airwheeltxt
    global touchtxt
    global taptxt
    global doubletaptxt

    xyztxt = ''
    flicktxt = ''
    flickcount = 0
    airwheeltxt = ''
    airwheelcount = 0
    touchtxt = ''
    touchcount = 0

    while True:
        xyztxt = ''

        if len(flicktxt) > 0 and flickcount < 1:  # 方向检测
            flickcount += 1
            direction = {"W": "西", "E": "东", "S": "南", "N": "北"}
            flickmsg = direction[flicktxt[6]] + direction[flicktxt[7]]
            if flickmsg == "东西":
                direction_msg = "左"
            elif flickmsg == "西东":
                direction_msg = "右"
            elif flickmsg == "南北":
                direction_msg = "上"
            elif flickmsg == "北南":
                direction_msg = "下"
            print direction_msg
        else:
            flicktxt = ''
            flickcount = 0

        if len(airwheeltxt) > 0 and airwheelcount < 1:  # 圆圈控制（airwheel顺时针增大，逆时针减小最多100）
            airwheelcount += 1
            print "控制值--->" + airwheeltxt
        else:
            airwheeltxt = ''
            airwheelcount = 0

        if len(touchtxt) > 0 and touchcount < 1:  # 检测触摸的部位
            touchcount += 1
            if touchtxt == "center":
                touch_msg = "中心部位"
            elif touchtxt == "east":
                touch_msg = "右边部位"
            elif touchtxt == "west":
                touch_msg = "左边部位"
            elif touchtxt == "south":
                touch_msg = "下边部位"
            elif touchtxt == "north":
                touch_msg = "上边部位"
            print touch_msg
        else:
            touchtxt = ''
            touchcount = 0

        time.sleep(0.1)

main()

