#!/usr/bin/env python
# coding: utf-8
#
import urllib2
import re

name = "T8620" #搜索关键字
site = "pan.baidu.com"#搜索站点
url = "http://www.baidu.com/s?wd=%s+site:%s" % (name, site)    #搜索的URL
maxPage = 3 #查询页面深度

regName = r"(文件名:)(.*)(文件大小:)(.*)(分享者:)"    #文件名
regUrl = r"(href = \")(http://www.baidu.com/link.*)(\")"    #url
regnextPageUrl = r"/s\?wd=[\d\w%&.=;-]*page=1"  #下一页

PageNameList = []
pageUrlList = []
PagesList = []

def main():
    html = getHtml(url)
    searchFile(html)
    searchUrl(html)
    #findPage(html)
    findNextPage(html)

def getHtml(url):
    response = urllib2.urlopen(url)
    return response.read()
#查找文件
def searchFile(text):
    if re.search(regName, text) != None:
        PageName_temp = re.findall(regName, text)
        for i in PageName_temp:
            PageNameList.append(
                "文件名:" + i[1].replace("<em>", "").replace("</em>", "")
                + " 文件大小:" + i[3]
            )
#查找链接
def searchUrl(text):
    if re.search(regUrl, text) != None:
        PageUrl_temp = re.findall(regUrl, text)
        for i in PageUrl_temp:
            pageUrlList.append(i[1])

def findPage(text):
    if re.search(pageUrl, text) != None:
        Page_temp = re.findall(pageUrl, text)
        for i in Page_temp:
            print i

#查找是否有“下一页”
def findNextPage(text):
    if re.search(regnextPageUrl, text) != None:
        url = "http://www.baidu.com" + re.search(regnextPageUrl, text).group()

#############################################################
###测试代码
#############################################################
# 根据最大页数，遍历所有页面
for i in range(0, maxPage):
    main()

# 打印所有文件
print "------------------Files : " + str(len(PageNameList)) + "----------------"
for f in PageNameList:
    print f.decode('utf-8').encode('gb2312')
#打印所有URl
print "------------------URL : " + str(len(pageUrlList)) + "----------------"
for u in pageUrlList:
    print u.decode('utf-8').encode('gb2312')
