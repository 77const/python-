#!/usr/bin/env python
# coding: utf-8
import requests
import json
import wave
import os
import serial
import time
import urllib2
import requests
# import RPi.GPIO as GPIO
from bs4 import BeautifulSoup
import sys
reload(sys)
sys.setdefaultencoding("utf-8")

__author__ = 'h77'

channel = 17

class Voice:
    """功能类"""
    def __init__(self):
        # self.ser = serial.Serial("/dev/ttyAMA0", 9600)
        apiKey = "ysdHW1gmg1SBjATw2gOvcrb8"  # 需要换成自己申请的
        secretKey = "4a2736cb1d85b0a9c3a21a4b759f67d8"  # 需要换成自己申请的
        # 百度API的key
        # 获取认证需要的token
        auth_url = "https://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=" + apiKey \
                   + "&client_secret=" + secretKey
        r = requests.get(auth_url)
        json_data = r.text
        self.token = json.loads(json_data)["access_token"]  # 处理获取到的信息

    @staticmethod
    def record(): # 录音
        os.system('arecord  -D plughw:0 -c 1 -d 3 1.wav -r 16000 -f S16_LE 2>/dev/null')

    def voice_to_message(self): # 语音转文字

        """
        语音转文字
        :return:
        """

        fp = wave.open('1.wav', 'rb')  # 打开声音文件
        nf = fp.getnframes()
        f_len = nf * 2
        audio_data = fp.readframes(nf)
        # 进行语音识别请求
        http_header = {'Content-Type': 'audio/pcm; rate=16000', 'Content-Length': '%d' % f_len}
        # print http_header
        cuid = "microduino"
        url_recover = 'http://vop.baidu.com/server_api' + '?cuid=' + cuid + '&token=' + self.token
        # print url_recover
        recover = requests.post(url_recover, data=audio_data, headers=http_header)
        out_dict = recover.text.encode("utf-8")
        out_dict_new = json.loads(out_dict)
        # print out_dict_new
        if "result" in out_dict_new:
            out = out_dict_new["result"][0]
            #print out.encode("utf-8")
            # 中文显示结果
            return out
        else:
            text = "......"
            return text

    @staticmethod
    def conversation(conversation_message): # 语言对话程序
        """
        语音交流
        :return:
        """
        # 通过联网获取交流结果
        auth_url_recover = ("http://www.tuling123.com/openapi/api?key=852bd32dab09088df7ce21bc2a6b7f6a&info=%s"
                            % conversation_message)
        sils = requests.get(auth_url_recover)
        text = sils.text.encode("utf-8")
        text_new = json.loads(text)
        text_old = text_new["text"]
        #print text_old.encode("utf-8")  # 中文显示结果
        if "list" in text_new:
            return text_new["list"]
        else:
            return text_old

    def message_to_voice(self, translate_message):  # 文字转语音
        """
        :param translate_message:
        :rtype:文字转语音
        """
        # 通过互联网把文字转成语音
        geturl = "http://tsn.baidu.com/text2audio?tex=" + \
                 translate_message + '&lan=zh&per=0&pit=5&spd=5&cuid=CCyo6UGf16ggKZGwGpQYL9Gx&ctp=1&tok=' + self.token
        #print geturl
        return os.system('mpg123 "%s" > /dev/null 2>&1' % geturl)  # 把转换好的语音播放出来

    def get_whether(self):
        content_text = "新余"
        name = urllib2.quote(content_text)  # 用于编码格式的转换
        url = 'http://v.juhe.cn/weather/index?format=2&cityname=%s&key=b7ab23c8e5026e5b07f15eb5f1f804a7' % name
        req = urllib2.Request(url)
        resp = urllib2.urlopen(req)
        content = resp.read()
        content_now = eval(content)
        city = content_now["result"]["today"]["city"]  # 城市
        today_week = content_now["result"]["today"]["week"]  # 今天的星期
        today_temperature = content_now["result"]["today"]["temperature"]  # 今天的温度
        today_weather = content_now["result"]["today"]["weather"]  # 今天的天气
        today_wind = content_now["result"]["today"]["wind"]  # 今天的风况
        today_date = content_now["result"]["today"]["date_y"]  # 今天的日期
        today_feel = content_now["result"]["today"]["dressing_index"]  # 今天的体感温度
        today_dress = content_now["result"]["today"]["dressing_advice"]  # 今天的穿衣指数

        message = "今天是" + today_week + today_date + "，" + city + "，" + \
                  "今天温度是　" + today_temperature + "，" + today_weather + "，" + "在户外会感觉到　" + today_dress
        return message

    def news(self):
        url = "http://news.qq.com/"
        # 请求腾讯新闻的URL，获取其text文本
        wbdata = requests.get(url).text
        # 对获取到的文本进行解析
        soup = BeautifulSoup(wbdata, 'lxml')
        # 从解析文件中通过select选择器定位指定的元素，返回一个列表
        news_titles = soup.select("div.text > em.f14 > a.linkto")
        # print news_titles
        # 对返回的列表进行遍历
        i = 0
        for n in news_titles:
            # 提取出标题和链接信息

            title = n.get_text()
            link = n.get("href")
            data = {
                '标题': title,
                '链接': link
            }
            if i < 5:
                i = i + 1
                print title
                self.message_to_voice(title)

    @staticmethod
    def rasspberry_takephotos():
        os.system('raspistill -o 1.jpg -w 1024 -h 768')  # 拍一张照片
        return "photos"

    @staticmethod
    def rasspberry_video():
        os.system('raspivid -t 5000 -w 800 -h 600 -o 1.h264')  # 录一段5秒钟的h264格式的视频
        os.system('MP4Box -add 1.h264 1.mp4')  # 转换为MP4格式
        return "mp4"

    def client_arduino_write(self, command):  # 串口

        """
        :type command: 串口通信发送的数据
        """
        self.ser.write(command)
        self.ser.close()
        return

    def client_arduino_read(self):
        """
        :return: 串口通信收到的数据
        """
        read_command = self.ser.inWaiting()
        if read_command != 0:
            command = self.ser.read(read_command)
            return command
        else:
            print "无命令提示"

    # def temperture(self):
    #     data = []
    #     j = 0
    #     GPIO.setmode(GPIO.BCM)
    #
    #     time.sleep(1)
    #
    #     GPIO.setup(channel, GPIO.OUT)
    #     GPIO.output(channel, GPIO.LOW)
    #     time.sleep(0.02)
    #     GPIO.output(channel, GPIO.HIGH)
    #     GPIO.setup(channel, GPIO.IN)
    #
    #     while GPIO.input(channel) == GPIO.LOW:
    #         continue
    #     while GPIO.input(channel) == GPIO.HIGH:
    #         continue
    #
    #     while j < 40:
    #         k = 0
    #         while GPIO.input(channel) == GPIO.LOW:
    #             continue
    #         while GPIO.input(channel) == GPIO.HIGH:
    #             k += 1
    #             if k > 100:
    #                 break
    #             if k < 8:
    #                 data.append(0)
    #             else:
    #                 data.append(1)
    #
    #             j += 1
    #
    #         # print "sensor is working."
    #         # print data
    #
    #         humidity_bit = data[0:8]
    #         humidity_point_bit = data[8:16]
    #         temperature_bit = data[16:24]
    #         temperature_point_bit = data[24:32]
    #         check_bit = data[32:40]
    #
    #         humidity = 0
    #         humidity_point = 0
    #         temperature = 0
    #         temperature_point = 0
    #         check = 0
    #
    #         for i in range(8):
    #             humidity += humidity_bit[i] * 2 ** (7 - i)
    #             humidity_point += humidity_point_bit[i] * 2 ** (7 - i)
    #             temperature += temperature_bit[i] * 2 ** (7 - i)
    #             temperature_point += temperature_point_bit[i] * 2 ** (7 - i)
    #             check += check_bit[i] * 2 ** (7 - i)
    #
    #         tmp = humidity + humidity_point + temperature + temperature_point
    #
    #         if check == tmp:
    #             # print "temperature :", temperature, "*C, humidity :", humidity, "%"
    #             f = file("/var/www/html/th/wth.th", "w+")
    #             li = ['{"temperature":%s,"humidity":%s}' % (temperature, humidity)]
    #             f.writelines(li)
    #             f.close()
    #             # else:
    #             # print "wrong"
    #             # print "temperature :", temperature, "*C, humidity :", humidity, "% check :", check, ", tmp :", tmp
    #
    #         time.sleep(5)
    #
    #         del data[:]
    #         j = 0
    #         GPIO.cleanup()

    @staticmethod
    def rasspberry_watch():
        os.system('raspivid -o - -t 0 -w 640 -h 360 -fps 25')
        return "video"

    def play_music(self,content):

        # content:音乐名字
        name = urllib2.quote(content)  # 用于编码格式的转换
        base_url = 'http://s.music.163.com/search/get/?type=1&s=%s&limit=1' % name
        # print base_url
        music_list = urllib2.urlopen(base_url).read()
        music = json.loads(music_list)
        # print music
        # 你可以采用字符串的拼接 或者字符串格式化
        if music[u'code'] == 200:
            music_id = music[u'result'][u'songs'][0][u'id']
            return music_id

    def Get_music(self,music_name):
        nane = self.play_music(music_name)
        url = "https://api.imjad.cn/cloudmusic/?type=song&id=%d&br=128000" % nane
        list_music = urllib2.urlopen(url).read()
        name = json.loads(list_music)
        # print name
        if name[u'code'] == 200:
            music_url = name[u'data'][0][u'url'].encode('utf-8')
            music = urllib2.urlopen(music_url)
            data = music.read()
            f = open('1.mp3', 'wb+')
            f.write(data)
            f.close()
            file_name = "1.mp3"
            print music_url
            os.system('mpg123 "%s" > /dev/null 2>&1' % file_name)

            return "歌曲播放完成．.."

    def write_msg(self, message):
        # file_msg = file("/var/www/html/th/wth.th", 'w+')
        file_msg = file("wth.th", 'w+')
        msg = ['{"chat_msg":%s}' % message]
        file_msg.writelines(msg)
        file_msg.close()

    def timeBios(self, hour_set, mines_set, sec_set):
        times = time.localtime()
        hour = times.tm_hour
        mines = times.tm_min
        sec = times.tm_sec
        if hour == hour_set and mines == mines_set and sec == sec_set:
            return True
        else:
            return  False

        # if mines == 0:
        #     alarm_time = "现在是北京时间%s点整。" % hour
        #     return alarm_time
        # else:
        #     now_time = "现在是北京时间%s点，%s分，%s秒" % (hour, mines, sec)
        #     return now_time
        #

    def mirror_control(self,command):
        camera_photos ="拍照"
        camera_video = "视频"
        weather = "天气"
        music = "播放"
        news = "新闻"
        curtain = "窗帘"
        air_conditioning = "空调"
        lamp = "灯"
        tv = "电视"
        open_control = "打开"
        close_control = "关闭"
        if open_control + curtain  in command:
            curtain_msg = "窗帘已打开..."
            control_command = "c"
            # self.client_arduino_write(control_command)
            self.message_to_voice(curtain_msg)
            # self.write_msg(curtain_msg)
            return curtain_msg
        elif close_control + curtain  in command:
            curtain_msg = "窗帘已关闭..."
            control_command = "o"
            # self.client_arduino_write(control_command)
            # self.message_to_voice(curtain_msg)
            # self.write_msg(curtain_msg)
            return curtain_msg
        elif open_control + air_conditioning  in command:
            air_conditioning_msg = "空调已打开..."
            control_command = "k"
           #  self.client_arduino_write(control_command)
           #  self.message_to_voice(air_conditioning_msg)
            # self.write_msg(air_conditioning_msg)
            return air_conditioning_msg
        elif close_control + air_conditioning  in command:
            air_conditioning_msg = "空调已关闭..."
            control_command = "n"
            # self.client_arduino_write(control_command)
            # self.message_to_voice(air_conditioning_msg)
            # self.write_msg(air_conditioning_msg)
            return air_conditioning_msg
        elif open_control + lamp in command:
            lamp_msg = "灯已打开..."
            control_command = "d"
            # self.client_arduino_write(control_command)
            # self.message_to_voice(lamp_msg)
            # self.write_msg(lamp_msg)
            return lamp_msg
        elif close_control + lamp in command:
            lamp_msg = "灯已关闭..."
            control_command = "v"
            # self.client_arduino_write(control_command)
            # self.message_to_voice(lamp_msg)
            # self.write_msg(lamp_msg)
            return lamp_msg
        elif open_control + tv in command:
            tv_msg = "电视已打开..."
            control_command = "q"
            # self.client_arduino_write(control_command)
            # self.message_to_voice(tv_msg)
            # self.write_msg(tv_msg)
            return tv_msg
        elif close_control + tv in command:
            tv_msg = "电视已关闭..."
            control_command = "w"
            # self.client_arduino_write(control_command)
            # self.message_to_voice(tv_msg)
            # self.write_msg(tv_msg)
            return tv_msg
        elif camera_photos in command:
            self.rasspberry_takephotos()
            return "拍照成功！！"
        elif camera_video in command:
            self.rasspberry_video()
            return "视频录制成功！！"
        elif news in command:
            self.news()
            return "新闻播报结束！！"
        elif weather in command:
            weather_prompt = self.get_whether()
            self.message_to_voice(weather_prompt)
            return " 天气播报结束！！"
        elif music in command:
            music_key = command.encode('utf-8')
            self.Get_music(" " + music_key[6:])
            return "音乐结束..."
        else:
            return_msg = self.conversation(command)
            return return_msg

    def main(self):
        self.record()
        tran_msg = self.voice_to_message()
        print tran_msg
        # print type(tran_msg)
        result_msg = self.mirror_control(tran_msg)
        self.message_to_voice(result_msg)
        self.write_msg(result_msg)
        print result_msg
        return result_msg

    def mirror_voice(self):
        keyword = "魔镜"
        while True:
            time_control = time.localtime()
            hour = time_control.tm_hour
            mines = time_control.tm_min
            sec = time_control.tm_sec
            if mines == 0 and sec < 3:
                alarm_time = "现在是北京时间%s点整。" % hour
                self.message_to_voice(alarm_time)
            self.record() # 录音
            get_msg = self.voice_to_message()
            print get_msg
            while keyword in get_msg:
                get_msg = "叮～～～"
                self.message_to_voice(get_msg)
                self.main()
                time.sleep(1)




