#!/usr/bin/env python
# coding: utf-8
#  import serial
import HTMLParser
import json
import mimetypes
import os
import random
import re
import sys
import time
import traceback
import urllib
import urllib2
import wave
import webbrowser
import xml.dom.minidom
from json import *
from traceback import format_exc
import string
import pyautogui
import pyqrcode
import requests
from requests.exceptions import ConnectionError, ReadTimeout
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage

__author__ = 'h77'
reload(sys)
sys.setdefaultencoding("utf-8")

UNKONWN = 'unkonwn'
SUCCESS = '200'
SCANED = '201'
TIMEOUT = '408'


def show_image(file_path):
    """
    跨平台显示图片文件
    :param file_path: 图片文件路径
    """
    if sys.version_info >= (3, 3):
        from shlex import quote
    else:
        from pipes import quote
    # print file_path
    # msg = open(file_path, 'rb').read()
    # email_image(msg)
    if sys.platform == "darwin":
        command = "open -a /Applications/Preview.app %s&" % quote(file_path)
        os.system(command)
    else:
        webbrowser.open(os.path.join(os.getcwd(), 'temp', file_path))

# def email_image(image_msg): # 发送全屏显示图片
#     _user = "Xobot@qq.com"  # 发件邮箱
#     _pwd = "alzyhmggmpgzbhfj"  # 发件授权码
#     _to = "1104042157@qq.com"
#
#     msg = MIMEMultipart('related') # 邮箱模式
#     theme = "智能管家一号"  # 邮件主题
#     msg["Subject"] = theme  # 载入主题
#     msg["From"] = _user  # 载入发送人
#     msg["To"] = _to  # 载入接收人
#
#     msgAlternative = MIMEMultipart('alternative') #
#     msg.attach(msgAlternative)
#
#     mail_msg = """
#     <p>智能管家微信登录二维码</p>
#     <p><img src="cid:image1"></p>
#     """
#     msgAlternative.attach(MIMEText(mail_msg, 'html', 'utf-8'))
#
#     msgImage = MIMEImage(image_msg)
#     # image_msg.close()
#     msgImage.add_header('Content-ID', '<image1>')
#     msg.attach(msgImage)
#
#     try:  # 尝试发送邮件
#         s = smtplib.SMTP_SSL("smtp.qq.com", 465)  # 发送域名及端口号
#         s.login(_user, _pwd)  # 登录发送邮箱账户
#         s.sendmail(_user, _to, msg.as_string())  # 发送邮件
#         s.quit()  # 发送完毕
#         print "Success!"
#     except smtplib.SMTPException, e:
#         print "Falied,%s" % e

class SafeSession(requests.Session):
    def request(self, method, url, params=None, data=None, headers=None, cookies=None, files=None, auth=None,
                timeout=None, allow_redirects=True, proxies=None, hooks=None, stream=None, verify=None,
                cert=None, json=None):
        for i in range(3):
            try:
                return super(SafeSession, self).request(method, url, params, data, headers, cookies, files, auth,
                                                        timeout,
                                                        allow_redirects, proxies, hooks, stream, verify, cert, json)
            except Exception as e:
                print e.message, traceback.format_exc()
                continue


class WXBot:
    """WXBot功能类"""

    def __init__(self):
        self.DEBUG = False
        self.uuid = ''
        self.base_uri = ''
        self.redirect_uri = ''
        self.uin = ''
        self.sid = ''
        self.skey = ''
        self.pass_ticket = ''
        self.device_id = 'e' + repr(random.random())[2:17]
        self.base_request = {}
        self.sync_key_str = ''
        self.sync_key = []
        self.sync_host = ''
        self.message = {}
        # 文件缓存目录
        self.temp_pwd = os.path.join(os.getcwd(), 'temp')
        if not os.path.exists(self.temp_pwd):
            os.makedirs(self.temp_pwd)

        self.session = SafeSession()
        self.session.headers.update({'User-Agent': 'Mozilla/5.0 (X11; Linux i686; U;) Gecko/20070322 Kazehakase/0.4.5'})
        self.conf = {'qr': 'png'}
        self.whether_message = " "
        self.my_account = {}  # 当前账户

        # 所有相关账号: 联系人, 公众号, 群组, 特殊账号
        self.member_list = []

        # 所有群组的成员, {'group_id1': [member1, member2, ...], ...}
        self.group_members = {}

        # 所有账户, {'group_member':{'id':{'type':'group_member', 'info':{}}, ...}, 'normal_member':{'id':{}, ...}}
        self.account_info = {'group_member': {}, 'normal_member': {}}

        self.contact_list = []  # 联系人列表
        self.public_list = []  # 公众账号列表
        self.group_list = []  # 群聊列表
        self.special_list = []  # 特殊账号列表
        self.encry_chat_room_id_list = []  # 存储群聊的EncryChatRoomId，获取群内成员头像时需要用到

        self.file_index = 0
        API_KEY = '52d85f0e329effad693daaadbfdf771f'
        API_SECRET = 'ZwWhZzegnfd2F42ejyZB5yp4roFIsjXC'

        apiKey = "ysdHW1gmg1SBjATw2gOvcrb8"  # 需要换成自己申请的
        secretKey = "4a2736cb1d85b0a9c3a21a4b759f67d8"  # 需要换成自己申请的
        # 百度API的key
        # 获取认证需要的token
        auth_url = "https://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=" + apiKey \
                   + "&client_secret=" + secretKey
        r = requests.get(auth_url)
        json_data = r.text
        self.token = json.loads(json_data)["access_token"]  # 处理获取到的信息
        self.city = ' '
        self.time = ' '
        self.high_temperature = ' '
        self.low_temperature = ' '
        self.wind_direction = ' '
        self.wind_size = ' '
        self.kind_d = ' '
        self.kind_n = ' '
        self.sugguestion_brf = ' '
        self.sugguestion_text = ' '
        self.suge_brf = ' '
        self.suge_text = ' '
        self.drsg_brf = ' '
        self.drsg_text = ' '
        self.flu_brf = ' '
        self.flu_text = ' '
        self.trav_brf = ' '
        self.trav_text = ' '
        self. uv_brf = ' '
        self. uv_text = ' '
        self.song_link = " "
        self.song_name = " "
        self.voice_key = True
        self.music_png = " "
        self.persons = []
        # self.ser = serial.Serial("/dev/ttyAMA0", 9600)

    @staticmethod
    def to_unicode(string, encoding='utf-8'):
        """
        将字符串转换为Unicode
        :param string: 待转换字符串
        :param encoding: 字符串解码方式
        :return: 转换后的Unicode字符串
        """
        if isinstance(string, str):
            return string.decode(encoding)
        elif isinstance(string, unicode):
            return string
        else:
            raise Exception('Unknown Type')

    def get_contact(self):
        """获取当前账户的所有相关账号(包括联系人、公众号、群聊、特殊账号)"""
        url = self.base_uri + '/webwxgetcontact?pass_ticket=%s&skey=%s&r=%s' \
                              % (self.pass_ticket, self.skey, int(time.time()))
        r = self.session.post(url, data='{}')
        r.encoding = 'utf-8'
        if self.DEBUG:
            with open(os.path.join(self.temp_pwd, 'contacts.json'), 'w') as f:
                f.write(r.text.encode('utf-8'))
        dic = json.loads(r.text)
        self.member_list = dic['MemberList']

        special_users = ['newsapp', 'fmessage', 'filehelper', 'weibo', 'qqmail',
                         'fmessage', 'tmessage', 'qmessage', 'qqsync', 'floatbottle',
                         'lbsapp', 'shakeapp', 'medianote', 'qqfriend', 'readerapp',
                         'blogapp', 'facebookapp', 'masssendapp', 'meishiapp',
                         'feedsapp', 'voip', 'blogappweixin', 'weixin', 'brandsessionholder',
                         'weixinreminder', 'wxid_novlwrv3lqwv11', 'gh_22b87fa7cb3c',
                         'officialaccounts', 'notification_messages', 'wxid_novlwrv3lqwv11',
                         'gh_22b87fa7cb3c', 'wxitil', 'userexperience_alarm', 'notification_messages']

        self.contact_list = []
        self.public_list = []
        self.special_list = []
        self.group_list = []

        for contact in self.member_list:
            if contact['VerifyFlag'] & 8 != 0:  # 公众号
                self.public_list.append(contact)
                self.account_info['normal_member'][contact['UserName']] = {'type': 'public', 'info': contact}
            elif contact['UserName'] in special_users:  # 特殊账户
                self.special_list.append(contact)
                self.account_info['normal_member'][contact['UserName']] = {'type': 'special', 'info': contact}
            elif contact['UserName'].find('@@') != -1:  # 群聊
                self.group_list.append(contact)
                self.account_info['normal_member'][contact['UserName']] = {'type': 'group', 'info': contact}
            elif contact['UserName'] == self.my_account['UserName']:  # 自己
                self.account_info['normal_member'][contact['UserName']] = {'type': 'self', 'info': contact}
            else:
                self.contact_list.append(contact)
                self.account_info['normal_member'][contact['UserName']] = {'type': 'contact', 'info': contact}

        self.batch_get_group_members()

        for group in self.group_members:
            for member in self.group_members[group]:
                if member['UserName'] not in self.account_info:
                    self.account_info['group_member'][member['UserName']] = \
                        {'type': 'group_member', 'info': member, 'group': group}

        if self.DEBUG:
            with open(os.path.join(self.temp_pwd, 'contact_list.json'), 'w') as f:
                f.write(json.dumps(self.contact_list))
            with open(os.path.join(self.temp_pwd, 'special_list.json'), 'w') as f:
                f.write(json.dumps(self.special_list))
            with open(os.path.join(self.temp_pwd, 'group_list.json'), 'w') as f:
                f.write(json.dumps(self.group_list))
            with open(os.path.join(self.temp_pwd, 'public_list.json'), 'w') as f:
                f.write(json.dumps(self.public_list))
            with open(os.path.join(self.temp_pwd, 'member_list.json'), 'w') as f:
                f.write(json.dumps(self.member_list))
            with open(os.path.join(self.temp_pwd, 'group_users.json'), 'w') as f:
                f.write(json.dumps(self.group_members))
            with open(os.path.join(self.temp_pwd, 'account_info.json'), 'w') as f:
                f.write(json.dumps(self.account_info))
        return True

    def batch_get_group_members(self):
        """批量获取所有群聊成员信息"""
        url = self.base_uri + '/webwxbatchgetcontact?type=ex&r=%s&pass_ticket=%s' % (int(time.time()), self.pass_ticket)
        params = {
            'BaseRequest': self.base_request,
            "Count": len(self.group_list),
            "List": [{"UserName": group['UserName'], "EncryChatRoomId": ""} for group in self.group_list]
        }
        r = self.session.post(url, data=json.dumps(params))
        r.encoding = 'utf-8'
        dic = json.loads(r.text)
        group_members = {}
        encry_chat_room_id = {}
        for group in dic['ContactList']:
            gid = group['UserName']
            members = group['MemberList']
            group_members[gid] = members
            encry_chat_room_id[gid] = group['EncryChatRoomId']
        self.group_members = group_members
        self.encry_chat_room_id_list = encry_chat_room_id

    def get_group_member_name(self, gid, uid):
        """
        获取群聊中指定成员的名称信息
        :param gid: 群id
        :param uid: 群聊成员id
        :return: 名称信息，类似 {"display_name": "test_user", "nickname": "test", "remark_name": "for_test" }
        """
        if gid not in self.group_members:
            return None
        group = self.group_members[gid]
        for member in group:
            if member['UserName'] == uid:
                names = {}
                if 'RemarkName' in member and member['RemarkName']:
                    names['remark_name'] = member['RemarkName']
                if 'NickName' in member and member['NickName']:
                    names['nickname'] = member['NickName']
                if 'DisplayName' in member and member['DisplayName']:
                    names['display_name'] = member['DisplayName']
                return names
        return None

    def get_contact_info(self, uid):
        return self.account_info['normal_member'].get(uid)

    def get_group_member_info(self, uid):
        return self.account_info['group_member'].get(uid)

    def get_contact_name(self, uid):
        info = self.get_contact_info(uid)
        if info is None:
            return None
        info = info['info']
        name = {}
        if 'RemarkName' in info and info['RemarkName']:
            name['remark_name'] = info['RemarkName']
        if 'NickName' in info and info['NickName']:
            name['nickname'] = info['NickName']
        if 'DisplayName' in info and info['DisplayName']:
            name['display_name'] = info['DisplayName']
        if len(name) == 0:
            return None
        else:
            return name

    @staticmethod
    def get_contact_prefer_name(name):
        if name is None:
            return None
        if 'remark_name' in name:
            return name['remark_name']
        if 'nickname' in name:
            return name['nickname']
        if 'display_name' in name:
            return name['display_name']
        return None

    @staticmethod
    def get_group_member_prefer_name(name):
        if name is None:
            return None
        if 'remark_name' in name:
            return name['remark_name']
        if 'display_name' in name:
            return name['display_name']
        if 'nickname' in name:
            return name['nickname']
        return None

    def get_user_type(self, wx_user_id):
        """
        获取特定账号与自己的关系
        :param wx_user_id: 账号id:
        :return: 与当前账号的关系
        """
        for account in self.contact_list:
            if wx_user_id == account['UserName']:
                return 'contact'
        for account in self.public_list:
            if wx_user_id == account['UserName']:
                return 'public'
        for account in self.special_list:
            if wx_user_id == account['UserName']:
                return 'special'
        for account in self.group_list:
            if wx_user_id == account['UserName']:
                return 'group'
        for group in self.group_members:
            for member in self.group_members[group]:
                if member['UserName'] == wx_user_id:
                    return 'group_member'
        return 'unknown'

    def is_contact(self, uid):
        for account in self.contact_list:
            if uid == account['UserName']:
                return True
        return False

    def is_public(self, uid):
        for account in self.public_list:
            if uid == account['UserName']:
                return True
        return False

    def is_special(self, uid):
        for account in self.special_list:
            if uid == account['UserName']:
                return True
        return False

    def wechat_main(self):
        print "------微信模式------"
        # img = Image.open("temp/xobot.png")
        # img.show()
        msg = self.message
        if msg['msg_type_id'] == 4 and msg['content']['type'] == 0 or msg['msg_type_id'] == 3:
            voice_text = msg["content"]['data']
            message = self.wechat_chatting(voice_text)
            if message == "语音":
                message = "微信模式开启"
                self.voice_key = True
                voice_commands = "语音模式开启"
                print voice_commands
                self.send_msg_by_uid(voice_commands, msg['user']['id'])
                self.voice_main()
            else:
                pass
            if message == "photos":
                self.send_img_msg_by_uid('1.jpg', msg['user']['id'])
            elif message == "mp4":
                self.send_file_msg_by_uid('1.mp4', msg['user']['id'])
                os.system('rm -rf 1.mp4')
            else:
                if message is not " ":
                    self.send_msg_by_uid(message, msg['user']['id'])
        else:
            return True

    def chat(self):
        msg = self.message
        if msg['msg_type_id'] == 4 and msg['content']['type'] == 0 or msg['msg_type_id'] == 3:
            voice_text = msg["content"]['data']
            message = self.wechat_chatting(voice_text)
            if message is not " ":
                self.send_msg_by_uid(message, msg['user']['id'])
    def xobot(self):
        """
        :rtype: 外部程序扩展


        t2 = threading.Thread(target=self.voice_main())
        t2.start()
        t2.join(1)

        t1 = threading.Thread(target=self.wechat_main())
        t1.start()
        t1.join(1)
        """
        pass

    @staticmethod
    def proc_at_info(msg):
        if not msg:
            return '', []
        segs = msg.split(u'\u2005')
        str_msg_all = ''
        str_msg = ''
        infos = []
        if len(segs) > 1:
            for i in range(0, len(segs) - 1):
                segs[i] += u'\u2005'
                pm = re.search(u'@.*\u2005', segs[i]).group()
                if pm:
                    name = pm[1:-1]
                    string = segs[i].replace(pm, '')
                    str_msg_all += string + '@' + name + ' '
                    str_msg += string
                    if string:
                        infos.append({'type': 'str', 'value': string})
                    infos.append({'type': 'at', 'value': name})
                else:
                    infos.append({'type': 'str', 'value': segs[i]})
                    str_msg_all += segs[i]
                    str_msg += segs[i]
            str_msg_all += segs[-1]
            str_msg += segs[-1]
            infos.append({'type': 'str', 'value': segs[-1]})
        else:
            infos.append({'type': 'str', 'value': segs[-1]})
            str_msg_all = msg
            str_msg = msg
        return str_msg_all.replace(u'\u2005', ''), str_msg.replace(u'\u2005', ''), infos

    def extract_msg_content(self, msg_type_id, msg):
        """
        content_type_id:
            0 -> Text
            1 -> Location
            3 -> Image
            4 -> Voice
            5 -> Recommend
            6 -> Animation
            7 -> Share
            8 -> Video
            9 -> VideoCall
            10 -> Redraw
            11 -> Empty
            99 -> Unknown
        :param msg_type_id: 消息类型id
        :param msg: 消息结构体
        :return: 解析的消息
        """
        mtype = msg['MsgType']
        content = HTMLParser.HTMLParser().unescape(msg['Content'])
        msg_id = msg['MsgId']

        msg_content = {}
        if msg_type_id == 0:
            return {'type': 11, 'data': ''}
        elif msg_type_id == 2:  # File Helper
            return {'type': 0, 'data': content.replace('<br/>', '\n')}
        elif msg_type_id == 3:  # 群聊
            sp = content.find('<br/>')
            uid = content[:sp]
            content = content[sp:]
            content = content.replace('<br/>', '')
            uid = uid[:-1]
            name = self.get_contact_prefer_name(self.get_contact_name(uid))
            if not name:
                name = self.get_group_member_prefer_name(self.get_group_member_name(msg['FromUserName'], uid))
            if not name:
                name = 'unknown'
            msg_content['user'] = {'id': uid, 'name': name}
        else:  # Self, Contact, Special, Public, Unknown
            pass

        msg_prefix = (msg_content['user']['name'] + ':') if 'user' in msg_content else ''

        if mtype == 1:
            if content.find('http://weixin.qq.com/cgi-bin/redirectforward?args=') != -1:
                r = self.session.get(content)
                r.encoding = 'gbk'
                data = r.text
                pos = self.search_content('title', data, 'xml')
                msg_content['type'] = 1
                msg_content['data'] = pos
                msg_content['detail'] = data
                if self.DEBUG:
                    print '    %s[Location] %s ' % (msg_prefix, pos)
            else:
                msg_content['type'] = 0
                if msg_type_id == 3 or (msg_type_id == 1 and msg['ToUserName'][:2] == '@@'):  # Group text message
                    msg_infos = self.proc_at_info(content)
                    str_msg_all = msg_infos[0]
                    str_msg = msg_infos[1]
                    detail = msg_infos[2]
                    msg_content['data'] = str_msg_all
                    msg_content['detail'] = detail
                    msg_content['desc'] = str_msg
                else:
                    msg_content['data'] = content
                if self.DEBUG:
                    try:
                        print '    %s[Text] %s' % (msg_prefix, msg_content['data'])
                    except UnicodeEncodeError:
                        print '    %s[Text] (illegal text).' % msg_prefix
        elif mtype == 3:
            msg_content['type'] = 3
            msg_content['data'] = self.get_msg_img_url(msg_id)
            msg_content['img'] = self.session.get(msg_content['data']).content.encode('hex')
            if self.DEBUG:
                image = self.get_msg_img(msg_id)
                print '    %s[Image] %s' % (msg_prefix, image)
        elif mtype == 34:
            msg_content['type'] = 4
            msg_content['data'] = self.get_voice_url(msg_id)
            msg_content['voice'] = self.session.get(msg_content['data']).content.encode('hex')
            if self.DEBUG:
                voice = self.get_voice(msg_id)
                print '    %s[Voice] %s' % (msg_prefix, voice)
        elif mtype == 37:
            msg_content['type'] = 37
            msg_content['data'] = msg['RecommendInfo']
            if self.DEBUG:
                print '    %s[useradd] %s' % (msg_prefix, msg['RecommendInfo']['NickName'])
        elif mtype == 42:
            msg_content['type'] = 5
            info = msg['RecommendInfo']
            msg_content['data'] = {'nickname': info['NickName'],
                                   'alias': info['Alias'],
                                   'province': info['Province'],
                                   'city': info['City'],
                                   'gender': ['unknown', 'male', 'female'][info['Sex']]}
            if self.DEBUG:
                print '    %s[Recommend]' % msg_prefix
                print '    -----------------------------'
                print '    | NickName: %s' % info['NickName']
                print '    | Alias: %s' % info['Alias']
                print '    | Local: %s %s' % (info['Province'], info['City'])
                print '    | Gender: %s' % ['unknown', 'male', 'female'][info['Sex']]
                print '    -----------------------------'
        elif mtype == 47:
            msg_content['type'] = 6
            msg_content['data'] = self.search_content('cdnurl', content)
            if self.DEBUG:
                print '    %s[Animation] %s' % (msg_prefix, msg_content['data'])
        elif mtype == 49:
            msg_content['type'] = 7
            if msg['AppMsgType'] == 3:
                app_msg_type = 'music'
            elif msg['AppMsgType'] == 5:
                app_msg_type = 'link'
            elif msg['AppMsgType'] == 7:
                app_msg_type = 'weibo'
            else:
                app_msg_type = 'unknown'
            msg_content['data'] = {'type': app_msg_type,
                                   'title': msg['FileName'],
                                   'desc': self.search_content('des', content, 'xml'),
                                   'url': msg['Url'],
                                   'from': self.search_content('appname', content, 'xml'),
                                   'content': msg.get('Content')  # 有的公众号会发一次性3 4条链接一个大图,如果只url那只能获取第一条,content里面有所有的链接
                                   }
            if self.DEBUG:
                print '    %s[Share] %s' % (msg_prefix, app_msg_type)
                print '    --------------------------'
                print '    | title: %s' % msg['FileName']
                print '    | desc: %s' % self.search_content('des', content, 'xml')
                print '    | link: %s' % msg['Url']
                print '    | from: %s' % self.search_content('appname', content, 'xml')
                print '    | content: %s' % (msg.get('content')[:20] if msg.get('content') else "unknown")
                print '    --------------------------'

        elif mtype == 62:
            msg_content['type'] = 8
            msg_content['data'] = content
            if self.DEBUG:
                print '    %s[Video] Please check on mobiles' % msg_prefix
        elif mtype == 53:
            msg_content['type'] = 9
            msg_content['data'] = content
            if self.DEBUG:
                print '    %s[Video Call]' % msg_prefix
        elif mtype == 10002:
            msg_content['type'] = 10
            msg_content['data'] = content
            if self.DEBUG:
                print '    %s[Redraw]' % msg_prefix
        elif mtype == 10000:  # unknown, maybe red packet, or group invite
            msg_content['type'] = 12
            msg_content['data'] = msg['Content']
            if self.DEBUG:
                print '    [Unknown]'
        else:
            msg_content['type'] = 99
            msg_content['data'] = content
            if self.DEBUG:
                print '    %s[Unknown]' % msg_prefix
        return msg_content

    def handle_msg(self, r):
        """
        处理原始微信消息的内部函数
        msg_type_id:
            0 -> Init
            1 -> Self
            2 -> FileHelper
            3 -> Group
            4 -> Contact
            5 -> Public
            6 -> Special
            99 -> Unknown
        :param r: 原始微信消息
        """
        for msg in r['AddMsgList']:
            user = {'id': msg['FromUserName'], 'name': 'unknown'}
            if msg['MsgType'] == 51:  # init message
                msg_type_id = 0
                user['name'] = 'system'
            elif msg['MsgType'] == 37:  # friend request
                msg_type_id = 37
                pass
                # content = msg['Content']
                # username = content[content.index('fromusername='): content.index('encryptusername')]
                # username = username[username.index('"') + 1: username.rindex('"')]
                # print u'[Friend Request]'
                # print u'       Nickname：' + msg['RecommendInfo']['NickName']
                # print u'       附加消息：'+msg['RecommendInfo']['Content']
                # # print u'Ticket：'+msg['RecommendInfo']['Ticket'] # Ticket添加好友时要用
                # print u'       微信号：'+username #未设置微信号的 腾讯会自动生成一段微信ID 但是无法通过搜索 搜索到此人
            elif msg['FromUserName'] == self.my_account['UserName']:  # Self
                msg_type_id = 1
                user['name'] = 'self'
            elif msg['ToUserName'] == 'filehelper':  # File Helper
                msg_type_id = 2
                user['name'] = 'file_helper'
            elif msg['FromUserName'][:2] == '@@':  # Group
                msg_type_id = 3
                user['name'] = self.get_contact_prefer_name(self.get_contact_name(user['id']))
            elif self.is_contact(msg['FromUserName']):  # Contact
                msg_type_id = 4
                user['name'] = self.get_contact_prefer_name(self.get_contact_name(user['id']))
            elif self.is_public(msg['FromUserName']):  # Public
                msg_type_id = 5
                user['name'] = self.get_contact_prefer_name(self.get_contact_name(user['id']))
            elif self.is_special(msg['FromUserName']):  # Special
                msg_type_id = 6
                user['name'] = self.get_contact_prefer_name(self.get_contact_name(user['id']))
            else:
                msg_type_id = 99
                user['name'] = 'unknown'
            if not user['name']:
                user['name'] = 'unknown'
            user['name'] = HTMLParser.HTMLParser().unescape(user['name'])

            if self.DEBUG and msg_type_id != 0:
                print u'[MSG] %s:' % user['name']
            content = self.extract_msg_content(msg_type_id, msg)
            self.message = {'msg_type_id': msg_type_id,
                            'msg_id': msg['MsgId'],
                            'content': content,
                            'to_user_id': msg['ToUserName'],
                            'user': user}
            # self.time_report()
            self.wechat_main()
            # self.chat()

    @staticmethod
    def schedule():
        """
        做任务型事情的函数，如果需要，可以在子类中覆盖此函数
        此函数在处理消息的间隙被调用，请不要长时间阻塞此函数
        """
        pass

    def proc_msg(self):
        self.test_sync_check()
        while True:
            check_time = time.time()
            try:
                [retcode, selector] = self.sync_check()
                # print '[DEBUG] sync_check:', retcode, selector
                if retcode == '1100':  # 从微信客户端上登出
                    break
                elif retcode == '1101':  # 从其它设备上登了网页微信
                    break
                elif retcode == '0':
                    if selector == '2':  # 有新消息
                        r = self.sync()
                        if r is not None:
                            self.handle_msg(r)
                    elif selector == '3':  # 未知
                        r = self.sync()
                        if r is not None:
                            self.handle_msg(r)
                    elif selector == '4':  # 通讯录更新
                        r = self.sync()
                        if r is not None:
                            self.get_contact()
                    elif selector == '6':  # 可能是红包
                        r = self.sync()
                        if r is not None:
                            self.handle_msg(r)
                    elif selector == '7':  # 在手机上操作了微信
                        r = self.sync()
                        if r is not None:
                            self.handle_msg(r)
                    elif selector == '0':  # 无事件
                        pass
                    else:
                        print '[DEBUG] sync_check:', retcode, selector
                        r = self.sync()
                        if r is not None:
                            self.handle_msg(r)
                else:
                    print '[DEBUG] sync_check:', retcode, selector
                self.schedule()
            except:
                print '[ERROR] Except in proc_msg'
                print format_exc()
            check_time = time.time() - check_time
            if check_time < 0.8:
                time.sleep(1 - check_time)

    def apply_useradd_requests(self, RecommendInfo):
        url = self.base_uri + '/webwxverifyuser?r=' + str(int(time.time())) + '&lang=zh_CN'
        params = {
            "BaseRequest": self.base_request,
            "Opcode": 3,
            "VerifyUserListSize": 1,
            "VerifyUserList": [
                {
                    "Value": RecommendInfo['UserName'],
                    "VerifyUserTicket": RecommendInfo['Ticket']}
            ],
            "VerifyContent": "",
            "SceneListCount": 1,
            "SceneList": [
                33
            ],
            "skey": self.skey
        }
        headers = {'content-type': 'application/json; charset=UTF-8'}
        data = json.dumps(params, ensure_ascii=False).encode('utf8')
        try:
            r = self.session.post(url, data=data, headers=headers)
        except (ConnectionError, ReadTimeout):
            return False
        dic = r.json()
        return dic['BaseResponse']['Ret'] == 0

    def add_groupuser_to_friend_by_uid(self, uid, VerifyContent):
        """
        主动向群内人员打招呼，提交添加好友请求
        uid-群内人员得uid   VerifyContent-好友招呼内容
        慎用此接口！封号后果自负！慎用此接口！封号后果自负！慎用此接口！封号后果自负！
        :param VerifyContent:
        :param uid:
        """
        if self.is_contact(uid):
            return True
        url = self.base_uri + '/webwxverifyuser?r=' + str(int(time.time())) + '&lang=zh_CN'
        params = {
            "BaseRequest": self.base_request,
            "Opcode": 2,
            "VerifyUserListSize": 1,
            "VerifyUserList": [
                {
                    "Value": uid,
                    "VerifyUserTicket": ""
                }
            ],
            "VerifyContent": VerifyContent,
            "SceneListCount": 1,
            "SceneList": [
                33
            ],
            "skey": self.skey
        }
        headers = {'content-type': 'application/json; charset=UTF-8'}
        data = json.dumps(params, ensure_ascii=False).encode('utf8')
        try:
            r = self.session.post(url, data=data, headers=headers)
        except (ConnectionError, ReadTimeout):
            return False
        dic = r.json()
        return dic['BaseResponse']['Ret'] == 0

    def add_friend_to_group(self, uid, group_name):
        """
        将好友加入到群聊中
        :param group_name:
        :param uid:
        """
        gid = ''
        # 通过群名获取群id,群没保存到通讯录中的话无法添加哦
        for group in self.group_list:
            if group['NickName'] == group_name:
                gid = group['UserName']
        if gid == '':
            return False
        # 通过群id判断uid是否在群中
        for user in self.group_members[gid]:
            if user['UserName'] == uid:
                # 已经在群里面了,不用加了
                return True
        url = self.base_uri + '/webwxupdatechatroom?fun=addmember&pass_ticket=%s' % self.pass_ticket
        params = {
            "AddMemberList": uid,
            "ChatRoomName": gid,
            "BaseRequest": self.base_request
        }
        headers = {'content-type': 'application/json; charset=UTF-8'}
        data = json.dumps(params, ensure_ascii=False).encode('utf8')
        try:
            r = self.session.post(url, data=data, headers=headers)
        except (ConnectionError, ReadTimeout):
            return False
        dic = r.json()
        return dic['BaseResponse']['Ret'] == 0

    def delete_user_from_group(self, uname, gid):
        """
        将群用户从群中剔除，只有群管理员有权限
        :param gid:
        :param uname:
        """
        uid = ""
        for user in self.group_members[gid]:
            if user['NickName'] == uname:
                uid = user['UserName']
        if uid == "":
            return False
        url = self.base_uri + '/webwxupdatechatroom?fun=delmember&pass_ticket=%s' % self.pass_ticket
        params ={
            "DelMemberList": uid,
            "ChatRoomName": gid,
            "BaseRequest": self.base_request
        }
        headers = {'content-type': 'application/json; charset=UTF-8'}
        data = json.dumps(params, ensure_ascii=False).encode('utf8')
        try:
            r = self.session.post(url, data=data, headers=headers)
        except (ConnectionError, ReadTimeout):
            return False
        dic = r.json()
        return dic['BaseResponse']['Ret'] == 0

    def send_msg_by_uid(self, word, dst='filehelper'):
        url = self.base_uri + '/webwxsendmsg?pass_ticket=%s' % self.pass_ticket
        msg_id = str(int(time.time() * 1000)) + str(random.random())[:5].replace('.', '')
        word = self.to_unicode(word)
        params = {
            'BaseRequest': self.base_request,
            'Msg': {
                "Type": 1,
                "Content": word,
                "FromUserName": self.my_account['UserName'],
                "ToUserName": dst,
                "LocalID": msg_id,
                "ClientMsgId": msg_id
            }
        }
        headers = {'content-type': 'application/json; charset=UTF-8'}
        data = json.dumps(params, ensure_ascii=False).encode('utf8')
        try:
            r = self.session.post(url, data=data, headers=headers)
        except (ConnectionError, ReadTimeout):
            return False
        dic = r.json()
        return dic['BaseResponse']['Ret'] == 0

    def upload_media(self, fpath, is_img=False):
        if not os.path.exists(fpath):
            print '[ERROR] File not exists.'
            return None
        url_1 = 'https://file.wx2.qq.com/cgi-bin/mmwebwx-bin/webwxuploadmedia?f=json'
        url_2 = 'https://file2.wx2.qq.com/cgi-bin/mmwebwx-bin/webwxuploadmedia?f=json'
        flen = str(os.path.getsize(fpath))
        ftype = mimetypes.guess_type(fpath)[0] or 'application/octet-stream'
        files = {
            'id': (None, 'WU_FILE_%s' % str(self.file_index)),
            'name': (None, os.path.basename(fpath)),
            'type': (None, ftype),
            'lastModifiedDate': (None, time.strftime('%m/%d/%Y, %H:%M:%S GMT+0800 (CST)')),
            'size': (None, flen),
            'mediatype': (None, 'pic' if is_img else 'doc'),
            'uploadmediarequest': (None, json.dumps({
                'BaseRequest': self.base_request,
                'ClientMediaId': int(time.time()),
                'TotalLen': flen,
                'StartPos': 0,
                'DataLen': flen,
                'MediaType': 4,
            })),
            'webwx_data_ticket': (None, self.session.cookies['webwx_data_ticket']),
            'pass_ticket': (None, self.pass_ticket),
            'filename': (os.path.basename(fpath), open(fpath, 'rb'), ftype.split('/')[1]),
        }
        self.file_index += 1
        try:
            r = self.session.post(url_1, files=files)
            # print json.loads(r.text)
            if json.loads(r.text)['BaseResponse']['Ret'] != 0:
                # 当file返回值不为0时则为上传失败，尝试第二服务器上传
                r = self.session.post(url_2, files=files)
            if json.loads(r.text)['BaseResponse']['Ret'] != 0:
                print '[ERROR] Upload media failure.'
                return None
            mid = json.loads(r.text)['MediaId']
            print mid
            return mid
        except Exception:
            return None

    def send_file_msg_by_uid(self, fpath, uid):  # 发文件
        mid = self.upload_media(fpath)
        if mid is None or not mid:
            return False
        url = self.base_uri + '/webwxsendappmsg?fun=async&f=json&pass_ticket=' + self.pass_ticket
        msg_id = str(int(time.time() * 1000)) + str(random.random())[:5].replace('.', '')
        data = {'BaseRequest': self.base_request,
                'Msg': {
                    'Type': 6,
                    'Content': ("<appmsg appid='wxeb7ec651dd0aefa9' sdkver=''><title>%s</title><des></des><action></action><type>6</type><content></content><url></url><lowurl></lowurl><appattach><totallen>%s</totallen><attachid>%s</attachid><fileext>%s</fileext></appattach><extinfo></extinfo></appmsg>" % (os.path.basename(fpath).encode('utf-8'), str(os.path.getsize(fpath)), mid, fpath.split('.')[-1])).encode('utf8'),
                    'FromUserName': self.my_account['UserName'],
                    'ToUserName': uid,
                    'LocalID': msg_id,
                    'ClientMsgId': msg_id, }, }
        try:
            r = self.session.post(url, data=json.dumps(data))
            res = json.loads(r.text)
            if res['BaseResponse']['Ret'] == 0:
                return True
            else:
                return False
        except Exception:
            return False

    def send_img_msg_by_uid(self, fpath, uid):  # 发照片
        mid = self.upload_media(fpath, is_img=True)
        if mid is None:
            return False
        url = self.base_uri + '/webwxsendmsgimg?fun=async&f=json'
        data = {'BaseRequest': self.base_request,
                 'Msg': {
                     'Type': 3,
                     'MediaId': mid,
                     'FromUserName': self.my_account['UserName'],
                     'ToUserName': uid,
                     'LocalID': str(time.time() * 1e7),
                     'ClientMsgId': str(time.time() * 1e7), }, }
        if fpath[-4:] == '.gif':
            url = self.base_uri + '/webwxsendemoticon?fun=sys'
            data['Msg']['Type'] = 47
            data['Msg']['EmojiFlag'] = 2
        try:
            r = self.session.post(url, data=json.dumps(data))
            res = json.loads(r.text)
            if res['BaseResponse']['Ret'] == 0:
                return True
            else:
                return False
        except Exception:
            return False

    def get_user_id(self, name):
        if name == '':
            return None
        name = self.to_unicode(name)
        for contact in self.contact_list:
            if 'RemarkName' in contact and contact['RemarkName'] == name:
                return contact['UserName']
            elif 'NickName' in contact and contact['NickName'] == name:
                return contact['UserName']
            elif 'DisplayName' in contact and contact['DisplayName'] == name:
                return contact['UserName']
        for group in self.group_list:
            if 'RemarkName' in group and group['RemarkName'] == name:
                return group['UserName']
            if 'NickName' in group and group['NickName'] == name:
                return group['UserName']
            if 'DisplayName' in group and group['DisplayName'] == name:
                return group['UserName']

        return ''

    def send_msg(self, name, word, isfile=False):
        uid = self.get_user_id(name)
        if uid is not None:
            if isfile:
                with open(word, 'r') as f:
                    result = True
                    for line in f.readlines():
                        line = line.replace('\n', '')
                        print '-> ' + name + ': ' + line
                        if self.send_msg_by_uid(line, uid):
                            pass
                        else:
                            result = False
                        time.sleep(1)
                    return result
            else:
                word = self.to_unicode(word)
                if self.send_msg_by_uid(word, uid):
                    return True
                else:
                    return False
        else:
            if self.DEBUG:
                print '[ERROR] This user does not exist .'
            return True

    @staticmethod
    def search_content(key, content, fmat='attr'):
        if fmat == 'attr':
            pm = re.search(key + '\s?=\s?"([^"<]+)"', content)
            if pm:
                return pm.group(1)
        elif fmat == 'xml':
            pm = re.search('<{0}>([^<]+)</{0}>'.format(key), content)
            if pm:
                return pm.group(1)
        return 'unknown'

    def run(self):
        self.get_uuid()
        self.gen_qr_code(os.path.join(self.temp_pwd, 'wxqr.png'))
        print '[INFO] Please use WeChat to scan the QR code .'

        result = self.wait4login()
        if result != SUCCESS:
            print '[ERROR] Web WeChat login failed. failed code=%s' % (result,)
            return

        if self.login():
            print '[INFO] Web WeChat login succeed .'
        else:
            print '[ERROR] Web WeChat login failed .'
            return

        if self.init():
            print '[INFO] Web WeChat init succeed .'
            show_image('xobot.png')
            time.sleep(1)
            pyautogui.press('f11')
        else:
            print '[INFO] Web WeChat init failed'
            return
        self.status_notify()
        self.get_contact()
        print '[INFO] Get %d contacts' % len(self.contact_list)
        print '[INFO] Start to process messages .'
        self.proc_msg()

    def get_uuid(self):
        url = 'https://login.weixin.qq.com/jslogin'
        params = {
            'appid': 'wx782c26e4c19acffb',
            'fun': 'new',
            'lang': 'zh_CN',
            '_': int(time.time()) * 1000 + random.randint(1, 999),
        }
        r = self.session.get(url, params=params)
        r.encoding = 'utf-8'
        data = r.text
        regx = r'window.QRLogin.code = (\d+); window.QRLogin.uuid = "(\S+?)"'
        pm = re.search(regx, data)
        if pm:
            code = pm.group(1)
            self.uuid = pm.group(2)
            return code == '200'
        return False

    def gen_qr_code(self, qr_file_path):
        string = 'https://login.weixin.qq.com/l/' + self.uuid
        """
        qrd = qrcode.QRCode(
                           version=1,
                           error_correction=qrcode.constants.ERROR_CORRECT_L,
                           box_size=10,
                           border=4,)

        qr = qrd.add_data(string)
        qrd.make(fit=True)
        # qr = qrd.make_image()
        """
        qr = pyqrcode.create(string)
        if self.conf['qr'] == 'png':
            # self.send_eamil(qr_file_path)
            qr.png(qr_file_path, scale=8)
            # img = Image.open('temp/xobot.png')
            # img.show()
            show_image(qr_file_path)  # 在windows下显示登陆二维码
            time.sleep(1)
            pyautogui.hotkey('tab', 'alt')
            time.sleep(1)
            pyautogui.press('f11')
            # print(qr.terminal(quiet_zone=1))  # 在liunx终端显示登陆二维码
            # self.display()

    def do_request(self, url):
        r = self.session.get(url)
        r.encoding = 'utf-8'
        data = r.text
        param = re.search(r'window.code=(\d+);', data)
        code = param.group(1)
        return code, data

    def wait4login(self):
        """
        http comet:
        tip=1, 等待用户扫描二维码,
               201: scaned
               408: timeout
        tip=0, 等待用户确认登录,
               200: confirmed
        """
        login_url = 'https://login.weixin.qq.com/cgi-bin/mmwebwx-bin/login?tip=%s&uuid=%s&_=%s'
        tip = 1

        try_later_secs = 1
        max_try_time = 10

        code = UNKONWN

        retry_time = max_try_time
        while retry_time > 0:
            url = login_url % (tip, self.uuid, int(time.time()))
            code, data = self.do_request(url)
            if code == SCANED:
                print '[INFO] Please confirm to login .'
                tip = 0
            elif code == SUCCESS:  # 确认登录成功
                param = re.search(r'window.redirect_uri="(\S+?)";', data)
                redirect_uri = param.group(1) + '&fun=new'
                self.redirect_uri = redirect_uri
                self.base_uri = redirect_uri[:redirect_uri.rfind('/')]
                return code
            elif code == TIMEOUT:
                print '[ERROR] WeChat login timeout. retry in %s secs later...' % (try_later_secs,)

                tip = 1  # 重置
                retry_time -= 1
                time.sleep(try_later_secs)
            else:
                print ('[ERROR] WeChat login exception return_code=%s. retry in %s secs later...' %
                       (code, try_later_secs))
                tip = 1
                retry_time -= 1
                time.sleep(try_later_secs)

        return code

    def login(self):
        if len(self.redirect_uri) < 4:
            print '[ERROR] Login failed due to network problem, please try again.'
            return False
        r = self.session.get(self.redirect_uri)
        r.encoding = 'utf-8'
        data = r.text
        doc = xml.dom.minidom.parseString(data)
        root = doc.documentElement

        for node in root.childNodes:
            if node.nodeName == 'skey':
                self.skey = node.childNodes[0].data
            elif node.nodeName == 'wxsid':
                self.sid = node.childNodes[0].data
            elif node.nodeName == 'wxuin':
                self.uin = node.childNodes[0].data
            elif node.nodeName == 'pass_ticket':
                self.pass_ticket = node.childNodes[0].data

        if '' in (self.skey, self.sid, self.uin, self.pass_ticket):
            return False

        self.base_request = {
            'Uin': self.uin,
            'Sid': self.sid,
            'Skey': self.skey,
            'DeviceID': self.device_id,
        }
        return True

    def init(self):
        url = self.base_uri + '/webwxinit?r=%i&lang=en_US&pass_ticket=%s' % (int(time.time()), self.pass_ticket)
        params = {
            'BaseRequest': self.base_request
        }
        r = self.session.post(url, data=json.dumps(params))
        r.encoding = 'utf-8'
        dic = json.loads(r.text)
        self.sync_key = dic['SyncKey']
        self.my_account = dic['User']
        self.sync_key_str = '|'.join([str(keyVal['Key']) + '_' + str(keyVal['Val'])
                                      for keyVal in self.sync_key['List']])
        return dic['BaseResponse']['Ret'] == 0

    def status_notify(self):
        url = self.base_uri + '/webwxstatusnotify?lang=zh_CN&pass_ticket=%s' % self.pass_ticket
        self.base_request['Uin'] = int(self.base_request['Uin'])
        params = {
            'BaseRequest': self.base_request,
            "Code": 3,
            "FromUserName": self.my_account['UserName'],
            "ToUserName": self.my_account['UserName'],
            "ClientMsgId": int(time.time())
        }
        r = self.session.post(url, data=json.dumps(params))
        r.encoding = 'utf-8'
        dic = json.loads(r.text)
        return dic['BaseResponse']['Ret'] == 0

    def test_sync_check(self):
        for host in ['wx', 'wx2']:
                self.sync_host = host
                try:
                    retcode = self.sync_check()[0]
                except:
                    retcode = -1
                if retcode == '0':
                    return True
        return False

    def sync_check(self):
        params = {
            'r': int(time.time()),
            'sid': self.sid,
            'uin': self.uin,
            'skey': self.skey,
            'deviceid': self.device_id,
            'synckey': self.sync_key_str,
            '_': int(time.time()),
        }
        url = 'https://' + self.sync_host + '.qq.com/cgi-bin/mmwebwx-bin/synccheck?' + urllib.urlencode(params)
        try:
            r = self.session.get(url, timeout=60)
            r.encoding = 'utf-8'
            data = r.text
            pm = re.search(r'window.synccheck=\{retcode:"(\d+)",selector:"(\d+)"\}', data)
            retcode = pm.group(1)
            selector = pm.group(2)
            return [retcode, selector]
        except:
            return [-1, -1]

    def sync(self):
        url = self.base_uri + '/webwxsync?sid=%s&skey=%s&lang=en_US&pass_ticket=%s' \
                              % (self.sid, self.skey, self.pass_ticket)
        params = {
            'BaseRequest': self.base_request,
            'SyncKey': self.sync_key,
            'rr': ~int(time.time())
        }
        try:
            r = self.session.post(url, data=json.dumps(params), timeout=60)
            r.encoding = 'utf-8'
            dic = json.loads(r.text)
            if dic['BaseResponse']['Ret'] == 0:
                self.sync_key = dic['SyncKey']
                self.sync_key_str = '|'.join([str(keyVal['Key']) + '_' + str(keyVal['Val'])
                                              for keyVal in self.sync_key['List']])
            return dic
        except:
            return None

    def get_icon(self, uid, gid=None):
        """
        获取联系人或者群聊成员头像
        :param uid: 联系人id
        :param gid: 群id，如果为非None获取群中成员头像，如果为None则获取联系人头像
        """
        if gid is None:
            url = self.base_uri + '/webwxgeticon?username=%s&skey=%s' % (uid, self.skey)
        else:
            url = self.base_uri + '/webwxgeticon?username=%s&skey=%s&chatroomid=%s' \
                                  % (uid, self.skey, self.encry_chat_room_id_list[gid])
        r = self.session.get(url)
        data = r.content
        fn = '1.jpg'
        with open(os.path.join(self.temp_pwd, fn), 'wb') as f:
            f.write(data)
        return fn

    def get_head_img(self, uid):
        """
        获取群头像
        :param uid: 群uid
        """
        url = self.base_uri + '/webwxgetheadimg?username=%s&skey=%s' % (uid, self.skey)
        r = self.session.get(url)
        data = r.content
        fn = '1.jpg'
        with open(os.path.join(self.temp_pwd, fn), 'wb') as f:
            f.write(data)
        return fn

    def get_msg_img_url(self, msgid):
        return self.base_uri + '/webwxgetmsgimg?MsgID=%s&skey=%s' % (msgid, self.skey)

    def get_msg_img(self, msgid):
        """
        获取图片消息，下载图片到本地
        :param msgid: 消息id
        :return: 保存的本地图片文件路径
        """
        url = self.base_uri + '/webwxgetmsgimg?MsgID=%s&skey=%s' % (msgid, self.skey)
        r = self.session.get(url)
        data = r.content
        # fn = 'img_' + msgid + '.jpg'
        fn = '1.jpg'
        with open(os.path.join(self.temp_pwd, fn), 'wb') as f:
            f.write(data)
        return fn

    def get_voice_url(self, msgid):
        return self.base_uri + '/webwxgetvoice ?msgid=%s&skey=%s' % (msgid, self.skey)

    def get_voice(self, msgid):
        """
        获取语音消息，下载语音到本地
        :param msgid: 语音消息id
        :return: 保存的本地语音文件路径
        """
        url = self.base_uri + '/webwxgetvoice?msgid=%s&skey=%s' % (msgid, self.skey)
        r = self.session.get(url)
        data = r.content
        fn = '2222.mp3'
        with open(os.path.join(self.temp_pwd, fn), 'wb+') as f:
            f.write(data)
        return fn

    def set_remarkname(self, uid, remarkname):  # 设置联系人的备注名
        url = self.base_uri + '/webwxoplog?lang=zh_CN&pass_ticket=%s' \
                              % self.pass_ticket
        remarkname = self.to_unicode(remarkname)
        params = {
            'BaseRequest': self.base_request,
            'CmdId': 2,
            'RemarkName': remarkname,
            'UserName': uid
        }
        try:
            r = self.session.post(url, data=json.dumps(params), timeout=60)
            r.encoding = 'utf-8'
            dic = json.loads(r.text)
            return dic['BaseResponse']['ErrMsg']
        except:
            return None


    @staticmethod
    def record():
        os.system('arecord  -D plughw:0 -c 1 -d 3 1.wav -r 16000 -f S16_LE 2>/dev/null')

    def voice_to_message(self):

        """
        语音转文字
        :return:
        """
        fp = wave.open('1.wav', 'rb')  # 打开声音文件
        nf = fp.getnframes()
        f_len = nf * 2
        audio_data = fp.readframes(nf)
        # 进行语音识别请求
        http_header = {'Content-Type': 'audio/pcm; rate=16000', 'Content-Length': '%d' % f_len}
        # print http_header
        cuid = "microduino"
        url_recover = 'http://vop.baidu.com/server_api' + '?cuid=' + cuid + '&token=' + self.token
        # print url_recover
        recover = requests.post(url_recover, data=audio_data, headers=http_header)
        out_dict = recover.text.encode("utf-8")
        out_dict_new = json.loads(out_dict)
        # print out_dict_new
        if "result" in out_dict_new:
            out = out_dict_new["result"][0]
            # print out.encode("utf-8")
            # 中文显示结果
            return out + "  "
        else:
            text = "没听明白，请再说一次"
            print text
            return text

    @staticmethod
    def conversation(conversation_message):
        """
        语音交流
        :return:
        :return:
        :param conversation_message:
        :return:
        """
        # 通过联网获取交流结果
        auth_url_recover = ("http://www.tuling123.com/openapi/api?key=852bd32dab09088df7ce21bc2a6b7f6a&info=%s"
                            % conversation_message)
        sils = requests.get(auth_url_recover)
        text = sils.text.encode("utf-8")
        text_new = json.loads(text)
        # print text_new
        text_old = text_new["text"]
        # print text_old.encode("utf-8")  # 中文显示结果
        if "list" in text_new:
            # print text_new["list"]
            return text_new["list"]
        else:
            return text_old

    def message_to_voice(self, translate_message):
        """
        :param translate_message:
        :rtype:文字转语音
        """
        # 通过互联网把文字转成语音
        geturl = "http://tsn.baidu.com/text2audio?tex=" + \
                 translate_message + '&lan=zh&per=0&pit=5&spd=5&cuid=CCyo6UGf16ggKZGwGpQYL9Gx&ctp=1&tok=' + self.token
        # print geturl
        return os.system('mpg123 "%s" > /dev/null 2>&1' % geturl)  # 把转换好的语音播放出来

    def report_control(self, command_text):  # 语音控制小车

        msg = self.message
        # 适合的语音命令组
        k_k = ("打开空调，", "空调，")
        k_q = ("关闭空调，", "关空调，")
        k_w = ("节能模式，", "开启节能模式，")
        camera_photos = ("拍照，", "照相，")
        camera_video = ("视频，", "录视频，", "拍视频，")
        voide = ("开启监控", "监控")
        forward = ("前进，", "向前走，", "前，", "前走，")
        backward = ("后退，", "往后退，", "向后，")
        left = ("向左转，", "左转，", "往左，", "左，", "左走，")
        right = ("向右转，", "右转，", "往右，", "右，", "右走，")
        left_row = ("往左转一圈", "左旋转")
        right_row = ("往右转一圈", "右旋转")
        stop = ("停，", "停止，", "停下来，", "停车，")
        commands = ("天气，", "天气预报，", "今天天气怎么样，", "今天天气，")
        off = ("关机，", "关掉系统，", "关，")
        reboot = ("重启系统，", "重新开启，", "重启，")
        song = ("放歌，", "播放歌曲，")
        night_command = ("开启夜间模式，", "防盗模式，")
        voice_commandss = ("微信，", "微信模式，")
        face_commands = ("启动人脸识别，", "启动人脸识别模式，", "人脸验证模式，")
        login_person = ("用户注册，", "人脸注册，")
        education_command = ("字怎么写，", "，")
        # print command_text
        if command_text in commands:
            print "播放天气"
            word = "正在获取天气,请稍等。。。"
            self.send_msg_by_uid(word, msg['user']['id'])
            message = self.report_whether()
            self.send_msg_by_uid(message, msg['user']['id'])
            self.message_to_voice(message)  # 语音播报部分天气情况
        elif command_text[1:] in education_command:
            print "练字模式"
            self.education(command_text[0].encode('utf-8'))
            self.send_img_msg_by_uid('temp/1.gif', msg['user']['id'])
            show_image('1.gif')
            time.sleep(1)
            pyautogui.press('f11')
            os.system('rm -rf 1.gif')
        elif command_text in face_commands:
            voice_commands = "请注意，正在开启摄像头进行人脸识别。。"
            self.send_msg_by_uid(voice_commands, msg['user']['id'])
            self.message_to_voice(voice_commands)
            self.rasspberry_takephotos()
            face_path = r'1.jpg'
            voice_commands = "请稍等，正在验证。。"
            self.send_msg_by_uid(voice_commands, msg['user']['id'])
            self.message_to_voice(voice_commands)
            result = self.check_face(face_path)
            self.send_msg_by_uid(result, msg['user']['id'])
            self.message_to_voice(result)
            os.system('rm -rf 1.jpg')
            # self.delet_none()  # 删除无用的用户和用户组
        elif command_text in login_person:
            voice_commands = "请注意，正在开启摄像头进行人脸注册。。"
            self.send_msg_by_uid(voice_commands, msg['user']['id'])
            self.message_to_voice(voice_commands)
            self.rasspberry_takephotos()
            face_path = r'1.jpg'
            voice_commands = "请稍等，正在注册。。"
            self.send_msg_by_uid(voice_commands, msg['user']['id'])
            self.message_to_voice(voice_commands)
            self.face_login(face_path)
            voice_commands = "注册成功。。"
            self.send_msg_by_uid(voice_commands, msg['user']['id'])
            self.message_to_voice(voice_commands)
        elif command_text in song:
            voice_commands = "请稍等，歌曲正在缓冲中。。。"
            self.send_msg_by_uid(voice_commands, msg['user']['id'])
            self.message_to_voice(voice_commands)  # 播报提示音
            os.system('mpg123  *.mp3')
        elif command_text in off:
            voice_commands = "智能管家系统即将关闭，祝您生活愉快，再见"
            self.send_msg_by_uid(voice_commands, msg['user']['id'])
            self.message_to_voice(voice_commands)  # 播报提示音
            os.system('sudo init 0 ')
        elif command_text in k_k:
            voice_commands = "请稍等，空调马上开启！"
            self.send_msg_by_uid(voice_commands, msg['user']['id'])
            self.message_to_voice(voice_commands)  # 播报提示音
        elif command_text in k_q:
            voice_commands = "空调关闭中···"
            self.send_msg_by_uid(voice_commands, msg['user']['id'])
            self.message_to_voice(voice_commands)  # 播报提示音
        elif command_text in k_w:
            voice_commands = "空调节能模式启动！"
            self.send_msg_by_uid(voice_commands, msg['user']['id'])
            self.message_to_voice(voice_commands)  # 播报提示音
        elif command_text in reboot:
            voice_commands = "请稍等，智能管家即将重新启动。"
            self.send_msg_by_uid(voice_commands, msg['user']['id'])
            self.message_to_voice(voice_commands)  # 播报提示音
            os.system('sudo init 6 ')
        elif command_text in camera_photos:
            voice_commands = "请注意，马上就要为您拍照"
            self.send_msg_by_uid(voice_commands, msg['user']['id'])
            self.message_to_voice(voice_commands)
            self.rasspberry_takephotos()
            text = "photos"
            return text
        elif command_text in camera_video:
            voice_commands = "现在开始监控5秒钟，摄像头即将开启"
            self.send_msg_by_uid(voice_commands, msg['user']['id'])
            self.message_to_voice(voice_commands)
            self.rasspberry_video()
            text = "mp4"
            return text
        elif command_text in voide:
            voice_commands = "请注意，摄像头马上开启"
            self.send_msg_by_uid(voice_commands, msg['user']['id'])
            self.message_to_voice(voice_commands)
            self.rasspberry_watch()
        elif command_text in left_row:
            voice_commands = "我要往左转圈咯。"
            self.message_to_voice(voice_commands)
        elif command_text in right_row:
            voice_commands = "我要往右转圈咯。"
            self.message_to_voice(voice_commands)
        elif command_text in forward:  # 如果语音命令符合
            voice_commands = " 马上就往前走。"  # 提示音
            self.message_to_voice(voice_commands)
        elif command_text in backward:
            voice_commands = " 请注意倒车、请注意倒车、请注意倒车！"
            self.message_to_voice(voice_commands)
        elif command_text in left:
            voice_commands = " 我要向左咯。"
            self.message_to_voice(voice_commands)
        elif command_text in right:
            voice_commands = " 请注意，我准备往右走啦。 "
            self.message_to_voice(voice_commands)
        elif command_text in stop:
            voice_commands = " 急什么？马上就停。"
            self.message_to_voice(voice_commands)
        elif command_text in night_command:
            voice_commands = "智能管家一号夜间模式开启！"
            self.message_to_voice(voice_commands)
        elif command_text in voice_commandss:
            command_text = "微信模式开启!"
            self.message_to_voice(command_text)
            self.voice_key = False
            print "微信模式开启"
        else:
            voice_text = self.conversation(command_text)  # 把对话文字提取出来
            return voice_text
        return " "

    def communication(self):  # 进行语音交流
        takeoff = ("不需要，", "不要，", "不，", "关，", "关机，", "不说了，")
        count_number = 1
        take_number = 0
        print "录音"
        self.record()  # 录音
        message_text = self.voice_to_message()  # 把语音翻译成文字
        while message_text == "没听明白，请再说一次":
            print "没听明白，请再说一次"
            self.record()
            message_text = self.voice_to_message()  # 把语音翻译成文字
            if message_text == "没听明白，请再说一次":
                self.message_to_voice(message_text)  # 把文字进行播放
                count_number += 1
                if count_number % 3 == 0:
                    take_number += 1
                    voice = "请问还需要什么服务？"
                    print voice
                    self.message_to_voice(voice)  # 把文字进行播放
                if take_number == 2:
                    value = 1
                    return value
        else:
            if message_text in takeoff:
                value = 1
                return value
            else:
                voice_text = self.report_control(message_text)
                self.message_to_voice(voice_text)  # 把文字进行播放
                return message_text

    def wechat_chatting(self, message_text):
        msg = self.message
        wechat_command = ("语音，", "语音模式，")
        recover_command = ("系统重启，", "系统重置，")
        message_text += "，"
        music = message_text.split('，')
        music_command = music[0].decode('utf-8')
        music_name = music[1].encode('utf-8')
        command = "播放,".split(',')[0].decode('utf-8')
        if message_text in wechat_command:
            text = "语音"
            return text
        elif message_text in recover_command:
            recover_text = "请稍等，系统即将重置。。"
            self.send_msg_by_uid(recover_text, msg['user']['id'])
            self.message_to_voice(recover_text)
            pyautogui.hotkey('ctrl', 'Z')
        elif music_command == command:
            voice_commands = "歌曲正在缓冲中。。。。"
            self.send_msg_by_uid(voice_commands, msg['user']['id'])
            self.Get_music(music_name)
        else:
            message_control = music[0] + "，"
            voice_text = self.report_control(message_control)
            return voice_text

    def voice_main(self):
        awkening = ("开启，", "开机，", "你好，", "系统开启，", "您好，")
        key = 0
        while key == 0 and self.voice_key:
            value = 0
            conversation_text = "你好，我是您的 智能管家。很高兴为您服务   "
            self.message_to_voice(conversation_text)  # 开机语音问候
            flog_text = "请注意，您每次说话有3秒的说话时间，请说话："
            self.message_to_voice(flog_text)
            message_text = " "
            while value != 1 and self.voice_key:
                value = self.communication()  # 语音聊天程序
                time.sleep(1)
            else:
                if self.voice_key is not False:
                    time.sleep(1)
                    voice = "智能管家系统即将进入休眠模式，可以用开机指令语音唤醒" \
                            "如果您要完全关闭智能管家，请唤醒后执行关机指令" \
                            "祝您生活愉快。再见！"
                    self.message_to_voice(voice)  # 把文字进行播放
                time.sleep(3)
                while message_text not in awkening and self.voice_key:
                    # self.feedback()
                    print "录音"
                    self.record()  # 录音
                    message_text = self.voice_to_message()  # 把语音翻译成文字
                    print message_text
                    if message_text not in "没听明白，请再说一次":
                        if message_text not in awkening:
                            flog_text = "您好，您的唤醒指令有误，请重新唤醒："
                            self.message_to_voice(flog_text)
                    else:
                        message_text = " "
                else:
                    key = 0
        else:
            pass

    def get_whether(self):
        url = 'http://apis.baidu.com/heweather/weather/free?city=xinyu'  # 可以更换成对应城市的拼音
        req = urllib2.Request(url)
        req.add_header("apikey", "382bb55e8fbc383b4feffdd4e8f6866a")
        # 百度天气获取的API
        resp = urllib2.urlopen(req)
        content = resp.read()
        content_now = eval(content)
        # 获取到的天气信息
        weather = content_now["HeWeather data service 3.0"]
        msg = weather[0]
        self.city = msg['basic']['city']  # 获取到的城市
        self.time = msg['basic']['update']['utc']  # 获取到的天气最后更新时间
        temperature = msg['daily_forecast'][0]['tmp']  # 获取到的当地温度
        self.high_temperature = temperature['max']  # 最高温
        self.low_temperature = temperature['min']  # 最低温

        wind = msg['daily_forecast'][0]['wind']  # 获取的风力信息
        self.wind_direction = wind['dir']  # 风向
        self.wind_size = wind['sc']  # 风速

        kind = msg['daily_forecast'][0]['cond']  # 获取的天气状况
        self.kind_d = kind['txt_d']  # 天气信息
        self.kind_n = kind['txt_n']  # 天气详细信息

        sugguestion = msg['suggestion']['comf']  # 获取到的当地城市舒适度
        self.sugguestion_brf = sugguestion['brf']  # 舒适度
        self.sugguestion_text = sugguestion['txt']  # 详细建议

        suge = msg['suggestion']['cw']  # 是否适合洗车情况
        self.suge_brf = suge['brf']  # 洗车指数
        self.suge_text = suge['txt']  # 洗车建议

        drsg = msg['suggestion']['drsg']  # 外出适合着装的建议
        self.drsg_brf = drsg['brf']  # 穿衣指数
        self.drsg_text = drsg['txt']  # 穿衣建议

        flu = msg['suggestion']['flu']  # 感冒发生情况
        self.flu_brf = flu['brf']  # 感冒指数
        self.flu_text = flu['txt']  # 避免感冒建议

        trav = msg['suggestion']['trav']  # 旅行建议
        self.trav_brf = trav['brf']  # 出行指数
        self.trav_text = trav['txt']  # 出行建议

        uv = msg['suggestion']['uv']  # 当地的辐射情况
        self. uv_brf = uv['brf']  # 辐射指数
        self. uv_text = uv['txt']  # 外出建议

    def print_whether(self):
        self.get_whether()
        """
        打印天气状况
        :return:
        """
        print '''
        The weather massage of %s:
            城市：%s
            天气状况：%s
            天气详情:%s
            更新时间：%s
            最高温度：%s
            最低温度：%s
            风向：%s
            风速：%s
            舒适度：%s
            舒适建议：%s
            洗车指数：%s
            洗车建议：%s
            穿衣指数：%s
            穿衣建议：%s
            感冒指数：%s
            预防感冒建议：%s
            出行指数：%s
            出行建议：%s
            辐射指数：%s
            外出建议：%s
        __________________________________
        ''' % (self.city, self.city, self.kind_n, self.kind_d, self.time, self.high_temperature, self.low_temperature,
               self.wind_direction, self.wind_size, self.sugguestion_brf, self.sugguestion_text, self.suge_brf,
               self.suge_text, self.drsg_brf, self.drsg_text,
               self.flu_brf, self.flu_text, self.trav_brf, self.trav_text, self.uv_brf, self.uv_text)
        pass

    def report_whether(self):
        self.get_whether()
        """
        播报天气，只是截取了部分天气情况进行播报
        :return:
        """
        report_city = self.city + ","
        report_weather = "天气状况" + ":" + self.kind_n + "," + self.kind_d + ","
        report_temperature = "最高温度" + ":" + self.high_temperature + ":" + "最低温度" + ":" + self.low_temperature + ","
        report_wind = "风力" + ":" + self.wind_direction + "," + self.wind_size + ","
        report_comfortable = "舒适度" + ":" + self.sugguestion_brf + "," + self.sugguestion_text + ","
        whether_message = report_city + report_weather + report_temperature + report_wind + report_comfortable + ","
        return whether_message

    @staticmethod
    def rasspberry_takephotos():
        os.system('raspistill -o 1.jpg -w 1024 -h 768')  # 拍一张照片
        return "photos"

    @staticmethod
    def rasspberry_video():
        os.system('raspivid -t 5000 -w 800 -h 600 -o 1.h264')  # 录一段5秒钟的h264格式的视频
        os.system('MP4Box -add 1.h264 1.mp4')  # 转换为MP4格式
        return "mp4"

    @staticmethod
    def rasspberry_watch():
        os.system('raspivid -o - -t 0 -w 640 -h 360 -fps 25')
        return "video"

    def feedback(self):  # 身份识别系统
        command = self.client_arduino_read()  # 读取串口命令
        if command == "F":
            print "主人回家"
            text = "欢迎主人回家，智能管家一号为您服务!"
            self.message_to_voice(text)
            command = "开机，"
            return command
        else:
            return False

    def night_alarm(self):  # 夜间报警系统
        # command = serial_client.client_arduino_read()  # 读取串口命令
        command = " "
        if command == "2":
            print "夜间报警"
            text = "警报！警报！有坏人入侵,智能管家一号开启一级警戒模式！"
            self.message_to_voice(text)
        else:
            return

    def time_report(self):  # 定制时间
        times = time.localtime()
        hour = times.tm_hour
        mines = times.tm_min
        sec = times.tm_sec
        print time.strftime("%a %b %d %H:%M:%S %Y", time.localtime())
        if mines == 0 and sec == 0:  # 整点报时
            text = "现在时间"
            self.message_to_voice(self.conversation(text))
            self.message_to_voice(self.report_whether())
            return True
        elif hour == 20 and mines == 0 and sec == 0:  # 20点整自动开启夜间巡逻模式
            text = "智能管家一号夜间模式开启！"
            self.message_to_voice(text)
            if mines == 0 and sec == 0:  # 夜间巡逻报警
                self.night_alarm()  # 夜间报警系统
        else:
            return False

    def client_arduino_write(self, command):  # 串口

        """
        :type command: 串口通信发送的数据
        """
        self.ser.write(command)
        self.ser.close()
        return

    def client_arduino_read(self):
        """
        :return: 串口通信收到的数据
        """
        read_command = self.ser.inWaiting()
        if read_command != 0:
            command = self.ser.read(read_command)
            return command
        else:
            print "无命令提示"

    @staticmethod
    def getcontent(url, pattern):  # 音乐网址
        try:
            f = urllib2.urlopen(url)
            result = f.read()
            content = re.compile(pattern, re.DOTALL)
            style = content.search(result)
            if style:
                result = style.group(0)
                return result
            else:
                return None
        except Exception, e:
            print e

    def get_music(self, music_name):  # 获取指定音乐
        song_tag_url = 'http://music.baidu.com/search?key=%s' % urllib.quote(music_name)
        song_link_url = 'http://play.baidu.com/data/music/songlink'
        i = 0
        result = self.getcontent(song_tag_url + '?start=' + unicode(i) + '&size=25&third_type=0', '<ul>.*?</ul>')
        sids = []
        sidPattern = re.findall("&quot;sid&quot;:.*?,&quot;", result)
        for sid in sidPattern:
            sids.append(re.sub(',&quot;', '', re.sub('&quot;sid&quot;:', '', sid)))
        formdata = {"songIds": ",".join(sids)}
        data_encoded = urllib.urlencode(formdata)
        songList = urllib2.urlopen(song_link_url, data_encoded)
        songListJson = songList.read()
        song_dict = JSONDecoder().decode(songListJson)
        song_data_dict = song_dict.get("data").get("songList")
        for sond_data in song_data_dict:
            self.song_name = sond_data.get('songName')
            song_artistName = sond_data.get('artistName')
            song_format = sond_data.get('format')
            self.song_link = sond_data.get('songLink')
            if self.song_name is None or \
                            song_artistName is None or \
                            song_format is None or \
                            self.song_link is None:
                continue
            print self.song_name + '--' + song_artistName + '.' + song_format + u'     下载链接为：'+ self.song_link
        self.down_music()

    def down_music(self):  # 下载音乐
        page = urllib.urlopen(self.song_link)
        data = page.read()
        fn = '%s.mp3' % self.song_name
        f = open(fn, 'wb+')
        f.write(data)
        f.close()

    def Get_music(self, content):
        msg = self.message
        # content:音乐名字
        name = urllib2.quote(content)  # 用于编码格式的转换
        base_url = 'http://s.music.163.com/search/get/?type=1&s=%s&limit=1' % name
        music_list = urllib2.urlopen(base_url).read()
        music = json.loads(music_list)
        # print music
        # 你可以采用字符串的拼接 或者字符串格式化
        if music[u'code'] == 200:
            music_Title = music[u'result'][u'songs'][0][u'album'][u'name'].encode('utf-8')
            music_Desc = music[u'result'][u'songs'][0][u'artists'][0][u'name'].encode('utf-8')
            music_Url = music[u'result'][u'songs'][0][u'audio'].encode('utf-8')
            self.music_png = music[u'result'][u'songs'][0][u'album'][u'picUrl'].encode('utf-8')
            imge = urllib2.urlopen(self.music_png)
            data = imge.read()
            f = open('1.jpg', 'wb+')
            f.write(data)
            f.close()
            self.send_img_msg_by_uid('1.jpg', msg['user']['id'])
            print music_Title, music_Desc, music_Url
            return os.system('mpg123 "%s" > /dev/null 2>&1' % music_Url)

    @staticmethod
    def education(content_text):  # 练字模式
        name = urllib2.quote(content_text)  # 用于编码格式的转换
        base_url = 'http://www.zhihuishan.com/bishun/?words=%s' % name
        result = urllib2.urlopen(base_url).read()
        reg = r'http://www.zhihuishan.com/data/gif/(\d+).gif'
        image= re.compile(reg)
        image_list = re.findall(image, result)
        img = image_list[1:][0]
        img_int=string.atoi(img)
        http = "http://www.zhihuishan.com/data/gif/%d.gif"% img_int
        data = urllib2.urlopen(http)
        data_text = data.read()
        # print data_text
        fn = r'temp/1.gif'
        f = open(fn, 'wb+')
        f.write(data_text)
        f.close()
        # print http
