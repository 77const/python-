#!/usr/bin/env python
# _*_coding:utf-8_*_
"""
date:2016年6月29日10:08:57
"""
from xobot_hourse import xobot_horse


class Wechat(xobot_horse.WXBot):
    pass


def wechat_init():
    wechat = Wechat()
    wechat.conf['qr'] = 'png'
    wechat.DEBUG = True
    wechat.run()


if __name__ == '__main__':
    wechat_init()
