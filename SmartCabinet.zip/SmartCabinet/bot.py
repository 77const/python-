#!/usr/bin/env python
# _*_coding:utf-8_*_

import wxbot


class Wechat(wxbot.WXBot):
    pass


def wechat_init():
    wechat = Wechat()
    wechat.conf['qr'] = 'png'
    wechat.DEBUG = True
    wechat.run()


if __name__ == '__main__':
    wechat_init()
