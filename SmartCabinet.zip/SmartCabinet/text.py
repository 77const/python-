#!/usr/bin/env python
# coding=utf-8
import time

flag = 1
while True:
    times = time.localtime()
    hour = times.tm_hour
    mines = times.tm_min
    sec = times.tm_sec
    if hour == 15:
        if mines % 2 == 0 and flag:
            flag = 0
            print mines
            print "发送"
        if mines % 2 == 1:
            flag = 1
