益佳智能药箱

bot.py 为执行程序
wxbot.py 为支撑程序

执行方式：sudo python bot.py

程序修改：sudo nano wxbot.py

益佳智能药箱程序修改地址，已在程序中注释完成，

# -------------------------智能药箱程序开始部分-------------------------------
程序主体（可修改部分）
# -------------------------智能药箱程序结束部分-------------------------------

其他部位的程序请不要修改。

所依赖的库文件：
os
smtplib
sys
traceback
webbrowser
pyqrcode
requests
mimetypes
json
xml.dom.minidom
urllib
time
re
random
traceback
bs4
HTMLParser
email
urllib2
wave
urllib
re
string
sys