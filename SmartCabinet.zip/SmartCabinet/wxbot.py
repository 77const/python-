#!/usr/bin/env python
# coding: utf-8
import os
import smtplib
import sys
import traceback
import webbrowser
import pyqrcode
import requests
import mimetypes
import json
import xml.dom.minidom
import urllib
import time
import re
import random
from traceback import format_exc
from bs4 import BeautifulSoup
from requests.exceptions import ConnectionError, ReadTimeout
import HTMLParser
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage
import urllib2
import wave
from urllib import quote
import re
import string
import sys

reload(sys)
sys.setdefaultencoding('utf8')
__author__ = 'h77'

# 2017年8月29日16:22:24
UNKONWN = 'unkonwn'
SUCCESS = '200'
SCANED = '201'
TIMEOUT = '408'
MdcineMessage = ["阿莫西林", 2, "氟哌酸胶囊", 3, "麦迪霉素", 1, "头孢氨苄胶囊", 2, "乙酰螺旋霉素片", 2, "土霉素片", 3]
TimeDictionary = {}
TimeMin = 0
TimeHour = 0

def map_username_batch(user_name):
    return {"UserName": user_name, "EncryChatRoomId": ""}


def show_image(file_path):
    """
    跨平台显示图片文件
    :param file_path: 图片文件路径
    """
    # print file_path
    # msg = open(file_path, 'rb').read()
    # email_image(msg)
    if sys.version_info >= (3, 3):
        from shlex import quote
    else:
        from pipes import quote

    if sys.platform == "darwin":
        command = "open -a /Applications/Preview.app %s&" % quote(file_path)
        os.system(command)
    else:
        webbrowser.open(os.path.join(os.getcwd(), 'temp', file_path))


def email_image(image_msg):  # 发送全屏显示图片
    _user = "Xobot@qq.com"  # 发件邮箱
    _pwd = "sdwzjvsghxxabijd"  # 发件授权码
    _to = "1104042157@qq.com"

    msg = MIMEMultipart('related')  # 邮箱模式
    theme = "益佳智能药箱"  # 邮件主题
    msg["Subject"] = theme  # 载入主题
    msg["From"] = _user  # 载入发送人
    msg["To"] = _to  # 载入接收人

    msgAlternative = MIMEMultipart('alternative')  #
    msg.attach(msgAlternative)

    mail_msg = """
    <p>益佳智能药箱微信登录二维码</p>
    <p><img src="cid:image1"></p>
    """
    msgAlternative.attach(MIMEText(mail_msg, 'html', 'utf-8'))

    msgImage = MIMEImage(image_msg)
    # image_msg.close()
    msgImage.add_header('Content-ID', '<image1>')
    msg.attach(msgImage)

    try:  # 尝试发送邮件
        s = smtplib.SMTP_SSL("smtp.qq.com", 465)  # 发送域名及端口号
        s.login(_user, _pwd)  # 登录发送邮箱账户
        s.sendmail(_user, _to, msg.as_string())  # 发送邮件
        s.quit()  # 发送完毕
        print "Success!"
    except smtplib.SMTPException, e:
        print "Falied,%s" % e


class SafeSession(requests.Session):
    def request(self, method, url, params=None, data=None, headers=None, cookies=None, files=None, auth=None,
                timeout=None, allow_redirects=True, proxies=None, hooks=None, stream=None, verify=None, cert=None,
                json=None):
        for i in range(3):
            try:
                return super(SafeSession, self).request(method, url, params, data, headers, cookies, files, auth,
                                                        timeout,
                                                        allow_redirects, proxies, hooks, stream, verify, cert, json)
            except Exception as e:
                print e.message, traceback.format_exc()
                continue

        # 重试3次以后再加一次，抛出异常
        try:
            return super(SafeSession, self).request(method, url, params, data, headers, cookies, files, auth,
                                                    timeout,
                                                    allow_redirects, proxies, hooks, stream, verify, cert, json)
        except Exception as e:
            raise e


class BaiduImage():
    def __init__(self, keyword, ):
        self.keyword = keyword
        self.count = 3
        self.save_path = "img"
        self.rn = 3

        self.__imageList = []
        self.__totleCount = 0

        self.__encodeKeyword = quote(self.keyword)
        self.__acJsonCount = self.__get_ac_json_count()

        self.user_agent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.95 Safari/537.36"
        self.headers = {'User-Agent': self.user_agent, "Upgrade-Insecure-Requests": 1,
                        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
                        "Accept-Encoding": "gzip, deflate, sdch",
                        "Accept-Language": "zh-CN,zh;q=0.8,en;q=0.6",
                        "Cache-Control": "no-cache"}
        # "Host": Host,

    def search(self):
        for i in range(0, self.__acJsonCount):
            url = self.__get_search_url(i * self.rn)
            response = self.__get_response(url).replace("\\", "")
            image_url_list = self.__pick_image_urls(response)
            self.__save(image_url_list)

    def __save(self, image_url_list, save_path=None):
        if save_path:
            self.save_path = save_path

        print "已经存储 " + str(self.__totleCount) + "张"
        print "正在存储 " + str(len(image_url_list)) + "张，存储路径：" + self.save_path

        if not os.path.exists(self.save_path):
            os.makedirs(self.save_path)

        for image in image_url_list:
            host = self.get_url_host(image)
            self.headers["Host"] = host

            with open(self.save_path + "/%s.jpg" % self.__totleCount, "wb") as p:
                try:
                    req = urllib2.Request(image, headers=self.headers)
                    # 设置一个urlopen的超时，如果10秒访问不到，就跳到下一个地址，防止程序卡在一个地方。
                    img = urllib2.urlopen(req, timeout=20)
                    p.write(img.read())
                    p.close()
                    self.__totleCount += 1
                except Exception as e:
                    print "Exception" + str(e)
                    p.close()
                    if os.path.exists("img/%s.jpg" % self.__totleCount):
                        os.remove("img/%s.jpg" % self.__totleCount)

        print "已存储 " + str(self.__totleCount) + " 张图片"

    def __pick_image_urls(self, response):
        reg = r'"ObjURL":"(http://img[0-9]\.imgtn.*?)"'
        imgre = re.compile(reg)
        imglist = re.findall(imgre, response)
        return imglist

    def __get_response(self, url):
        page = urllib2.urlopen(url)
        return page.read()

    def __get_search_url(self, pn):
        return "http://image.baidu.com/search/acjson?tn=resultjson_com&ipn=rj&ct=201326592&is=&fp=result&queryWord=" + self.__encodeKeyword + "&cl=2&lm=-1&ie=utf-8&oe=utf-8&adpicid=&st=-1&z=&ic=0&word=" + self.__encodeKeyword + "&s=&se=&tab=&width=&height=&face=0&istype=2&qc=&nc=1&fr=&pn=" + str(
            pn) + "&rn=" + str(self.rn) + "&gsm=1000000001e&1486375820481="

    def get_url_host(self, url):
        reg = r'http://(.*?)/'
        hostre = re.compile(reg)
        host = re.findall(hostre, url)
        if len(host) > 0:
            return host[0]
        return ""

    def __get_ac_json_count(self):
        a = self.count % self.rn
        c = self.count / self.rn
        if a:
            c += 1
        return c


class WXBot:
    """WXBot功能类"""

    def __init__(self):
        self.DEBUG = False
        self.uuid = ''
        self.base_uri = ''
        self.base_host = ''
        self.redirect_uri = ''
        self.uin = ''
        self.sid = ''
        self.skey = ''
        self.pass_ticket = ''
        self.device_id = 'e' + repr(random.random())[2:17]
        self.base_request = {}
        self.sync_key_str = ''
        self.sync_key = []
        self.sync_host = ''
        self.message = {}
        status = 'wait4login'  # 表示机器人状态，供WEBAPI读取，WxbotManage使用
        bot_conf = {}  # 机器人配置，在webapi初始化的时候传入，后续也可修改，WxbotManage使用

        self.batch_count = 50  # 一次拉取50个联系人的信息
        self.full_user_name_list = []  # 直接获取不到通讯录时，获取的username列表
        self.wxid_list = []  # 获取到的wxid的列表
        self.cursor = 0  # 拉取联系人信息的游标
        self.is_big_contact = False  # 通讯录人数过多，无法直接获取
        # 文件缓存目录
        self.temp_pwd = os.path.join(os.getcwd(), 'temp')
        if os.path.exists(self.temp_pwd) == False:
            os.makedirs(self.temp_pwd)

        self.session = SafeSession()
        self.session.headers.update({'User-Agent': 'Mozilla/5.0 (X11; Linux i686; U;) Gecko/20070322 Kazehakase/0.4.5'})
        self.conf = {'qr': 'png'}

        self.my_account = {}  # 当前账户

        # 所有相关账号: 联系人, 公众号, 群组, 特殊账号
        self.member_list = []

        # 所有群组的成员, {'group_id1': [member1, member2, ...], ...}
        self.group_members = {}

        # 所有账户, {'group_member':{'id':{'type':'group_member', 'info':{}}, ...}, 'normal_member':{'id':{}, ...}}
        self.account_info = {'group_member': {}, 'normal_member': {}}

        self.contact_list = []  # 联系人列表
        self.public_list = []  # 公众账号列表
        self.group_list = []  # 群聊列表
        self.special_list = []  # 特殊账号列表
        self.encry_chat_room_id_list = []  # 存储群聊的EncryChatRoomId，获取群内成员头像时需要用到

        self.file_index = 0

        # self.ser = serial.Serial("/dev/ttyAMA0", 9600)
        apiKey = "ysdHW1gmg1SBjATw2gOvcrb8"  # 需要换成自己申请的
        secretKey = "4a2736cb1d85b0a9c3a21a4b759f67d8"  # 需要换成自己申请的
        # 百度API的key
        # 获取认证需要的token
        auth_url = "https://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=" + apiKey \
                   + "&client_secret=" + secretKey
        r = requests.get(auth_url)
        json_data = r.text
        self.token = json.loads(json_data)["access_token"]  # 处理获取到的信息
        self.message_news = " "
        self.messageid = True


    @staticmethod
    def record():  # 录音
        os.system('arecord  -D plughw:0 -c 1 -d 3 1.wav -r 16000 -f S16_LE 2>/dev/null')

    def voice_to_message(self):  # 语音转文字

        """
        语音转文字
        :return:
        """

        fp = wave.open('1.wav', 'rb')  # 打开声音文件
        nf = fp.getnframes()
        f_len = nf * 2
        audio_data = fp.readframes(nf)
        # 进行语音识别请求
        http_header = {'Content-Type': 'audio/pcm; rate=16000', 'Content-Length': '%d' % f_len}
        # print http_header
        cuid = "microduino"
        url_recover = 'http://vop.baidu.com/server_api' + '?cuid=' + cuid + '&token=' + self.token
        # print url_recover
        recover = requests.post(url_recover, data=audio_data, headers=http_header)
        out_dict = recover.text.encode("utf-8")
        out_dict_new = json.loads(out_dict)
        # print out_dict_new
        if "result" in out_dict_new:
            out = out_dict_new["result"][0]
            # print out.encode("utf-8")
            # 中文显示结果
            return out
        else:
            text = "......"
            return text

    @staticmethod
    def conversation(conversation_message):  # 语言对话程序
        """
        语音交流
        :return:
        """
        # 通过联网获取交流结果
        auth_url_recover = ("http://www.tuling123.com/openapi/api?key=852bd32dab09088df7ce21bc2a6b7f6a&info=%s"
                            % conversation_message)
        sils = requests.get(auth_url_recover)
        text = sils.text.encode("utf-8")
        text_new = json.loads(text)
        text_old = text_new["text"]
        # print text_old.encode("utf-8")  # 中文显示结果
        if "list" in text_new:
            return text_new["list"]
        else:
            return text_old

    def message_to_voice(self, translate_message):  # 文字转语音
        """
        :param translate_message:
        :rtype:文字转语音
        """
        # 通过互联网把文字转成语音
        geturl = "http://tsn.baidu.com/text2audio?tex=" + \
                 translate_message + '&lan=zh&per=0&pit=5&spd=5&cuid=CCyo6UGf16ggKZGwGpQYL9Gx&ctp=1&tok=' + self.token
        # print geturl
        return os.system('mpg123 "%s" > /dev/null 2>&1' % geturl)  # 把转换好的语音播放出来

    def get_whether(self):
        content_text = "新余"
        name = urllib2.quote(content_text)  # 用于编码格式的转换
        url = 'http://v.juhe.cn/weather/index?format=2&cityname=%s&key=b7ab23c8e5026e5b07f15eb5f1f804a7' % name
        req = urllib2.Request(url)
        resp = urllib2.urlopen(req)
        content = resp.read()
        content_now = eval(content)
        city = content_now["result"]["today"]["city"]  # 城市
        today_week = content_now["result"]["today"]["week"]  # 今天的星期
        today_temperature = content_now["result"]["today"]["temperature"]  # 今天的温度
        today_weather = content_now["result"]["today"]["weather"]  # 今天的天气
        today_wind = content_now["result"]["today"]["wind"]  # 今天的风况
        today_date = content_now["result"]["today"]["date_y"]  # 今天的日期
        today_feel = content_now["result"]["today"]["dressing_index"]  # 今天的体感温度
        today_dress = content_now["result"]["today"]["dressing_advice"]  # 今天的穿衣指数

        message = "今天是" + today_week + today_date + "，" + city + "，" + \
                  "今天温度是　" + today_temperature + "，" + today_weather + "，" + "在户外会感觉到　" + today_dress
        return message

    def news(self):
        global message
        message = " "
        url = "http://news.qq.com/"
        # 请求腾讯新闻的URL，获取其text文本
        wbdata = requests.get(url).text
        # 对获取到的文本进行解析
        soup = BeautifulSoup(wbdata, 'lxml')
        # 从解析文件中通过select选择器定位指定的元素，返回一个列表
        news_titles = soup.select("div.text > em.f14 > a.linkto")
        # print news_titles
        # 对返回的列表进行遍历
        i = 0
        for n in news_titles:
            # 提取出标题和链接信息
            i += 1
            title = n.get_text().encode("utf-8")
            link = n.get("href").encode("utf-8")
            data = " \n %s \n %s \n" % (title, link)
            if i <= 5:
                message = message + data
                self.message_news = self.message_news + title + ",  "
        return message

    def sersch(self, image_name):
        search = BaiduImage(image_name)
        search.search()

    @staticmethod
    def rasspberry_takephotos():
        os.system('raspistill -o 1.jpg -w 1024 -h 768')  # 拍一张照片
        return "photos"

    @staticmethod
    def rasspberry_video():
        os.system('raspivid -t 5000 -w 800 -h 600 -o 1.h264')  # 录一段5秒钟的h264格式的视频
        os.system('MP4Box -add 1.h264 1.mp4')  # 转换为MP4格式
        return "mp4"

    def client_arduino_write(self, command):  # 串口

        """
        :type command: 串口通信发送的数据
        """
        self.ser.write(command)
        self.ser.close()
        return

    def client_arduino_read(self):
        """
        :return: 串口通信收到的数据
        """
        read_command = self.ser.inWaiting()
        if read_command != 0:
            command = self.ser.read(read_command)
            return command
        else:
            print "无命令提示"

    # def temperture(self):
    #     data = []
    #     j = 0
    #     GPIO.setmode(GPIO.BCM)
    #
    #     time.sleep(1)
    #
    #     GPIO.setup(channel, GPIO.OUT)
    #     GPIO.output(channel, GPIO.LOW)
    #     time.sleep(0.02)
    #     GPIO.output(channel, GPIO.HIGH)
    #     GPIO.setup(channel, GPIO.IN)
    #
    #     while GPIO.input(channel) == GPIO.LOW:
    #         continue
    #     while GPIO.input(channel) == GPIO.HIGH:
    #         continue
    #
    #     while j < 40:
    #         k = 0
    #         while GPIO.input(channel) == GPIO.LOW:
    #             continue
    #         while GPIO.input(channel) == GPIO.HIGH:
    #             k += 1
    #             if k > 100:
    #                 break
    #             if k < 8:
    #                 data.append(0)
    #             else:
    #                 data.append(1)
    #
    #             j += 1
    #
    #         # print "sensor is working."
    #         # print data
    #
    #         humidity_bit = data[0:8]
    #         humidity_point_bit = data[8:16]
    #         temperature_bit = data[16:24]
    #         temperature_point_bit = data[24:32]
    #         check_bit = data[32:40]
    #
    #         humidity = 0
    #         humidity_point = 0
    #         temperature = 0
    #         temperature_point = 0
    #         check = 0
    #
    #         for i in range(8):
    #             humidity += humidity_bit[i] * 2 ** (7 - i)
    #             humidity_point += humidity_point_bit[i] * 2 ** (7 - i)
    #             temperature += temperature_bit[i] * 2 ** (7 - i)
    #             temperature_point += temperature_point_bit[i] * 2 ** (7 - i)
    #             check += check_bit[i] * 2 ** (7 - i)
    #
    #         tmp = humidity + humidity_point + temperature + temperature_point
    #
    #         if check == tmp:
    #             # print "temperature :", temperature, "*C, humidity :", humidity, "%"
    #             f = file("/var/www/html/th/wth.th", "w+")
    #             li = ['{"temperature":%s,"humidity":%s}' % (temperature, humidity)]
    #             f.writelines(li)
    #             f.close()
    #             # else:
    #             # print "wrong"
    #             # print "temperature :", temperature, "*C, humidity :", humidity, "% check :", check, ", tmp :", tmp
    #
    #         time.sleep(5)
    #
    #         del data[:]
    #         j = 0
    #         GPIO.cleanup()

    @staticmethod
    def rasspberry_watch():
        os.system('raspivid -o - -t 0 -w 640 -h 360 -fps 25')
        return "video"

    def introduce(self):
        private_msg = """
---------------------
     使用说明
---------------------
功能｜使用方式
---------------------
聊天｜任意文字（群聊需＠）
---------------------
天气｜默认｜城市＋天气
---------------------
新闻｜新闻（今天新闻）
---------------------
音乐｜播放＋歌名
---------------------
图片｜某某＋图片
---------------------
家电｜空调.灯.电视.窗帘
---------------------
控制｜打开／关闭＋家电 
---------------------
讲笑话.查快递.拍照.视频
---------------------
后续功能，开发中。。。。
---------------------
        """
        return private_msg

    def play_music(self, content, msg):
        # content:音乐名字
        name = urllib2.quote(content)  # 用于编码格式的转换
        base_url = 'http://s.music.163.com/search/get/?type=1&s=%s&limit=1' % name
        # print base_url
        music_list = urllib2.urlopen(base_url).read()
        music = json.loads(music_list)
        # print music
        # 你可以采用字符串的拼接 或者字符串格式化
        if music[u'code'] == 200:
            if music.has_key(u"result") and music[u'result'][u'songs'] != []:
                music_id = music[u'result'][u'songs'][0][u'id']
                music_png = music[u'result'][u'songs'][0][u'album'][u'picUrl'].encode('utf-8')
                png_msg = urllib2.urlopen(music_png).read()
                f = open('ge.jpg', 'wb+')
                f.write(png_msg)
                f.close()
                self.send_img_msg_by_uid('ge.jpg', msg['user']['id'])
                os.system('rm -rf ge.jpg')
                return music_id
            else:
                remind_message = False
                return remind_message

    def Get_music(self, music_name, msg):
        nane = self.play_music(music_name, msg)
        if nane is not False:
            url = "https://api.imjad.cn/cloudmusic/?type=song&id=%d&br=128000" % nane
            list_music = urllib2.urlopen(url).read()
            name = json.loads(list_music)
            # print name
            if name[u'code'] == 200:
                music_url = name[u'data'][0][u'url'].encode('utf-8')
                music = urllib2.urlopen(music_url)
                data = music.read()
                f = open('1.mp3', 'wb+')
                f.write(data)
                f.close()
                file_name = "1.mp3"
                # print music_url
                self.send_msg_by_uid(music_url, msg['user']['id'])
                os.system('mpg123 "%s" > /dev/null 2>&1' % file_name)
                return "歌曲播放完成．.."
        else:
            remind_message = "此歌曲已下架，请换首试试。。"
            # print remind_message
            return remind_message

    def write_msg(self, message):
        file_msg = file("/var/www/html/th/wth.th", 'w+')
        # file_msg = file("wth.th", 'w+')
        msg = ['{"chat_msg":"%s"}' % message]
        file_msg.writelines(msg)
        file_msg.close()

    def write_wth(self, message):
        file_msg = file("/var/www/html/th/mth.th", 'w+')
        # file_msg = file("wth.th", 'w+')
        msg = ['{"chat_msg":"%s"}' % message]
        file_msg.writelines(msg)
        file_msg.close()

    def timeBios(self, hour_set, mines_set, sec_set):
        times = time.localtime()
        hour = times.tm_hour
        mines = times.tm_min
        sec = times.tm_sec
        if hour == hour_set and mines == mines_set and sec == sec_set:
            return True
        else:
            return False

            # if mines == 0:
            #     alarm_time = "现在是北京时间%s点整。" % hour
            #     return alarm_time
            # else:
            #     now_time = "现在是北京时间%s点，%s分，%s秒" % (hour, mines, sec)
            #     return now_time
            #

    def hand_control(self):
        f = open('hand.txt', 'r')
        hand_message = f.read()
        f.close()
        # print hand_message
        return hand_message

    def hand(self, msg):
        hand_message = self.hand_control()
        if hand_message is not None:
            handmsg = self.hand_control()
            if hand_message != handmsg:
                print handmsg
                if handmsg == "上":
                    curtain_msg = "空调已打开。。。"
                    self.write_msg(curtain_msg)
                    self.send_msg_by_uid(curtain_msg, msg['user']['id'])
                    self.message_to_voice(curtain_msg)
                elif handmsg == "下":
                    curtain_msg = "空调已关闭。。。"
                    self.write_msg(curtain_msg)
                    self.send_msg_by_uid(curtain_msg, msg['user']['id'])
                    self.message_to_voice(curtain_msg)
                elif handmsg == "右":
                    curtain_msg = "窗帘已关闭。。。"
                    self.write_msg(curtain_msg)
                    self.send_msg_by_uid(curtain_msg, msg['user']['id'])
                    self.message_to_voice(curtain_msg)
                elif handmsg == "左":
                    curtain_msg = "窗帘已打开。。。"
                    self.write_msg(curtain_msg)
                    self.send_msg_by_uid(curtain_msg, msg['user']['id'])
                    self.message_to_voice(curtain_msg)
                elif handmsg == "中心部位":
                    curtain_msg = "手势模式关闭"
                    self.write_msg(curtain_msg)
                    self.send_msg_by_uid(curtain_msg, msg['user']['id'])
                    self.message_to_voice(curtain_msg)
                    self.messageid = False

    def mirror_control(self, command, msg):
        # print type(command)
        camera_photos = "拍照"
        camera_video = "视频"
        weather = "天气"
        music = "播放"
        news = "新闻"
        curtain = "窗帘"
        air_conditioning = "空调"
        lamp = "灯"
        tv = "电视"
        open_control = "打开"
        close_control = "关闭"
        image = "图片"
        introduce = "介绍"
        hand = "手势"
        voice = "语音"
        wechat = "微信"
        if open_control + curtain in command:
            curtain_msg = "窗帘已打开..."
            control_command = "c"
            # self.client_arduino_write(control_command)
            self.write_msg(curtain_msg)
            self.send_msg_by_uid(curtain_msg, msg['user']['id'])
            self.message_to_voice(curtain_msg)
            # self.write_msg(curtain_msg)
            return curtain_msg
        elif close_control + curtain in command:
            curtain_msg = "窗帘已关闭..."
            control_command = "o"
            # self.client_arduino_write(control_command)
            self.write_msg(curtain_msg)
            self.send_msg_by_uid(curtain_msg, msg['user']['id'])
            self.message_to_voice(curtain_msg)
            # self.write_msg(curtain_msg)
            return curtain_msg
        elif open_control + air_conditioning in command:
            air_conditioning_msg = "空调已打开..."
            control_command = "k"
            #  self.client_arduino_write(control_command)
            self.write_msg(air_conditioning_msg)
            self.send_msg_by_uid(air_conditioning_msg, msg['user']['id'])
            self.message_to_voice(air_conditioning_msg)
            # self.write_msg(air_conditioning_msg)
            return air_conditioning_msg
        elif close_control + air_conditioning in command:
            air_conditioning_msg = "空调已关闭..."
            control_command = "n"
            # self.client_arduino_write(control_command)
            self.write_msg(air_conditioning_msg)
            self.send_msg_by_uid(air_conditioning_msg, msg['user']['id'])
            self.message_to_voice(air_conditioning_msg)
            # self.write_msg(air_conditioning_msg)
            return air_conditioning_msg
        elif open_control + lamp in command:
            lamp_msg = "灯已打开..."
            control_command = "d"
            # self.client_arduino_write(control_command)
            self.write_msg(lamp_msg)
            self.send_msg_by_uid(lamp_msg, msg['user']['id'])
            self.message_to_voice(lamp_msg)
            # self.write_msg(lamp_msg)
            return lamp_msg
        elif close_control + lamp in command:
            lamp_msg = "灯已关闭..."
            control_command = "v"
            # self.client_arduino_write(control_command)
            self.write_msg(lamp_msg)
            self.send_msg_by_uid(lamp_msg, msg['user']['id'])
            self.message_to_voice(lamp_msg)
            # self.write_msg(lamp_msg)
            return lamp_msg
        elif open_control + tv in command:
            tv_msg = "电视已打开..."
            control_command = "q"
            # self.client_arduino_write(control_command)
            self.write_msg(tv_msg)
            self.send_msg_by_uid(tv_msg, msg['user']['id'])
            self.message_to_voice(tv_msg)
            # self.write_msg(tv_msg)
            return tv_msg
        elif close_control + tv in command:
            tv_msg = "电视已关闭..."
            control_command = "w"
            # self.client_arduino_write(control_command)
            self.write_msg(tv_msg)
            self.send_msg_by_uid(tv_msg, msg['user']['id'])
            self.message_to_voice(tv_msg)
            # self.write_msg(tv_msg)
            return tv_msg
        elif camera_photos in command:
            remind = "请稍等，摄像头正在开启。。"
            self.rasspberry_takephotos()
            self.send_msg_by_uid(remind, msg['user']['id'])
            return "photos"
        elif camera_video in command:
            remind_video = "视频录制中。。。。"
            self.rasspberry_video()
            self.send_msg_by_uid(remind_video, msg['user']['id'])
            return "mp4"
        elif news in command:
            news_msg = self.news()
            print news_msg
            self.send_msg_by_uid(news_msg, msg['user']['id'])
            self.message_to_voice(self.message_news)
            print self.message_news
            return "新闻播报结束！！"
        elif introduce in command:
            self.send_msg_by_uid(self.introduce(), msg['user']['id'])
            return "欢迎使用"
        elif weather in command:
            weather_msg = self.conversation(command)
            if weather_msg.encode("utf-8") == "亲爱的，悄悄地告诉我你在哪个城市？":
                weather_prompt = self.get_whether()
                self.send_msg_by_uid(weather_prompt, msg['user']['id'])
                self.message_to_voice(weather_prompt)
                return " 天气播报结束！！"
            else:
                whether_text = self.conversation(command)
                return whether_text
        elif image in command:
            self.sersch(command)
            if os.path.isfile('img/0.jpg'):
                self.send_img_msg_by_uid('img/0.jpg', msg['user']['id'])
                self.send_img_msg_by_uid('img/1.jpg', msg['user']['id'])
                self.send_img_msg_by_uid('img/2.jpg', msg['user']['id'])
            else:
                msg_remind = "对不起，您所搜索的图片未找到。。"
                self.send_msg_by_uid(msg_remind, msg['user']['id'])
            os.system('rm -rf img')
        elif music in command:
            # music_key = command.encode('utf-8')
            remind_music = "请稍等，正在寻找音乐。。"
            self.send_msg_by_uid(remind_music, msg['user']['id'])
            music_msg = self.Get_music(" " + command[6:], msg)
            self.send_msg_by_uid(music_msg, msg['user']['id'])
            return "音乐结束..."
        elif hand in command:
            handts = "手势模式开始"
            self.send_msg_by_uid(handts, msg['user']['id'])
            while self.messageid:
                self.hand(msg)
            return "微信模式开启"
        elif voice in command:
            self.messageid = True
            voicemsg = "控制方式｜魔镜，魔镜 + 控制指令"
            self.write_msg(voicemsg)
            voicets = "语音模式开始"
            self.send_msg_by_uid(voicets, msg['user']['id'])
            self.mirror_voice(msg)
            return "微信模式开启"
        else:
            return_msg = self.conversation(command)
            return return_msg

    def main(self, msg):
        wechat = "微信"
        self.record()
        tran_msg = self.voice_to_message()
        print tran_msg
        if tran_msg in wechat:
            print self.messageid
            self.messageid = False
        # print type(tran_msg)
        result_msg = self.mirror_control(tran_msg, msg)
        self.message_to_voice(result_msg)
        self.write_wth(result_msg)
        print result_msg
        return result_msg

    def mirror_voice(self, msg):
        keyword = "魔镜"
        while self.messageid:
            time_control = time.localtime()
            hour = time_control.tm_hour
            mines = time_control.tm_min
            sec = time_control.tm_sec
            if mines == 0 and sec < 3:
                alarm_time = "现在是北京时间%s点整。" % hour
                self.message_to_voice(alarm_time)
            self.record()  # 录音
            get_msg = self.voice_to_message()
            print get_msg
            while keyword in get_msg:
                get_msg = "叮～～～"
                self.message_to_voice(get_msg)
                self.main(msg)
                time.sleep(1)

    def wechat_main(self, msg):
        print "------微信模式------"
        # img = Image.open("temp/xobot.png")
        # img.show()
        # print msg
        if msg['msg_type_id'] == 4 and msg['content']['type'] == 0:
            voice_text = msg["content"]['data'].encode("utf-8")
            message = self.mirror_control(voice_text, msg)
            if message == "photos":
                self.send_img_msg_by_uid('1.jpg', msg['user']['id'])
            elif message == "mp4":
                self.send_file_msg_by_uid('1.mp4', msg['user']['id'])
                os.system('rm -rf 1.mp4')
            else:
                if message is not " ":
                    self.write_wth(message)
                    self.message_to_voice(message)
                    self.send_msg_by_uid(message, msg['user']['id'])
        elif msg['msg_type_id'] == 3 and msg['content']['type'] == 0:
            group_msg = msg["content"]['data'].encode("utf-8")
            if "@Xobot" in group_msg:
                message_group = self.mirror_control(group_msg.replace('@xobot', ''), msg)
                if message_group is not " ":
                    self.send_msg_by_uid(message_group, msg['user']['id'])
        else:
            return True
# -------------------------智能药箱程序开始部分-------------------------------
# 功能说明

    def ReadMe(self):
        readme = """
    益佳智能药箱使用说明
---------------------
    药箱功能｜使用方式
---------------------
设置药品信息｜查询药箱信息
---------------------
设置服药时间｜查询服药时间
---------------------
服药情况查询｜身体数据查询
---------------------
    健康建议｜生活助手
---------------------
后续功能，开发中。。。。
---------------------
                """
        return readme

    # 药品信息

    def medicine(self, firstbox, firstmdc, secondbox, secondmdc, thirdbox, thirdmdc, fourbox, fourmdc, fivebox, fivemdc,
                 sixbox, sixmdc):
        medicine_msg = """
益佳智能药箱药品信息
---------------------
药盒药名｜服药颗数
---------------------
1号药盒｜%s|%s|
---------------------
2号药盒｜%s|%s|
---------------------
3号药盒｜%s|%s|
---------------------
4号药盒｜%s|%s|
---------------------
5号药盒｜%s|%s|
---------------------
6号药盒｜%s|%s|
---------------------
                    """ % (
            firstbox, firstmdc, secondbox, secondmdc, thirdbox, thirdmdc, fourbox, fourmdc, fivebox, fivemdc, sixbox,
            sixmdc)
        return medicine_msg
    # 服药次数

    def MedicineNumber(self, TimeMessage, msglen):
        if TimeMessage[2] is ':':
            TimeMin = "%s%s" % (TimeMessage[3], TimeMessage[4])
            TimeHour = "%s%s" % (TimeMessage[0], TimeMessage[1])
        elif TimeMessage[1] is ':':
            TimeMin = "%s%s" % (TimeMessage[2], TimeMessage[3])
            TimeHour = "%s" % (TimeMessage[0])
        else:
            if len(TimeMessage) == 7:
                TimeMin = "%s%s" % (TimeMessage[5], TimeMessage[6])
                TimeHour = "%s%s" % (TimeMessage[0], TimeMessage[1])
            else:
                TimeMin = "%s%s" % (TimeMessage[4], TimeMessage[5])
                TimeHour = "%s" % (TimeMessage[0])
        TimeResult = "您所设定的第%s次服药时间为：%s点%s分" % (msglen, TimeHour, TimeMin)
        return TimeResult

    def CountDown(self, num, TimeMessage):
        times = time.localtime()
        hour = times.tm_hour
        mines = times.tm_min
        if TimeMessage[2] is ':':
            TimeMin = "%s%s" % (TimeMessage[3], TimeMessage[4])
            TimeHour = "%s%s" % (TimeMessage[0], TimeMessage[1])
        elif TimeMessage[1] is ':':
            TimeMin = "%s%s" % (TimeMessage[2], TimeMessage[3])
            TimeHour = "%s" % (TimeMessage[0])
        else:
            if len(TimeMessage) == 7:
                TimeMin = "%s%s" % (TimeMessage[5], TimeMessage[6])
                TimeHour = "%s%s" % (TimeMessage[0], TimeMessage[1])
            else:
                TimeMin = "%s%s" % (TimeMessage[4], TimeMessage[5])
                TimeHour = "%s" % (TimeMessage[0])
        if int(TimeHour) < hour:
            ResultMines = 24 * 60 - hour * 60 - mines + int(TimeHour) * 60 + int(TimeMin)
            EndHour = ResultMines / 60
            Endmines = ResultMines % 60
        elif int(TimeHour) > hour:
            ResultMines = (int(TimeHour) * 60 + int(TimeMin)) - (hour * 60 + mines)
            EndHour = ResultMines / 60
            Endmines = ResultMines % 60
        else:
            if mines < int(TimeMin):
                ResultMines = int(TimeMin) - mines
                ResultMsg = "您所设定的第%s次服药时间为：%s点%s分，现在是：%s点%s分；距离服药时间还剩：0小时%s分钟" \
                            % (num, TimeHour, TimeMin, hour, mines, ResultMines)
                return ResultMsg
            elif mines > int(TimeMin):
                ResultMines = 24 * 60 - hour * 60 - mines + int(TimeHour) * 60 + int(TimeMin)
                EndHour = ResultMines / 60
                Endmines = ResultMines % 60
            else:
                ResultMines = 0
                ResultMsg = "您所设定的第%s次服药时间为：%s点%s分，现在是：%s点%s分；距离服药时间还剩：0小时%s分钟" \
                            % (num, TimeHour, TimeMin, hour, mines, ResultMines)
                return ResultMsg
        ResultMsg = "您所设定的第%s次服药时间为：%s点%s分，现在是：%s点%s分；距离服药时间还剩：%s小时%s分钟" \
                    % (num, TimeHour, TimeMin, hour, mines, EndHour, Endmines)
        return ResultMsg
    # 益佳智能药箱控制程序

    def CabinetControl(self, message):
        global TimeHour, flag, TimeMin, flagtext, EndHour, Endmines, TimeData
        TimeData = " "
        SetTimeMsg = "设置服药"
        AskTime = "时间"
        msgtext = "说明"
        SetMedicine = "设置药品信息"
        boxtext = "药盒"
        health = "健康"
        life = "生活"
        bodydata = "身体"
        if SetTimeMsg in message:
            SetFormat = "请设定服药次数及服药时间(24h),例如:第一次：08:00 -- 配置完毕后发送（时间设置完毕）"
            flag = 1
            return SetFormat
        elif "次" in message and flag == 1:
            msglen = message[3:6]
            if message[9] == ":":
                TimeMessage = list(message[10:])
            else:
                TimeMessage = list(message[12:])
            TimeDictionary[msglen] = TimeMessage
            print TimeDictionary
            return self.MedicineNumber(TimeMessage, msglen)
        elif "时间设置完毕" in message or AskTime in message:
            flag = 0
            for num in range(0, len(TimeDictionary)):
                num = num + 1
                chinesenumber = {1: "一", 2: "二", 3: "三", 4: "四", 5: "五"}
                TimeMessage = TimeDictionary[chinesenumber[num]]
                TimeData = TimeData +"\n" + self.CountDown(chinesenumber[num], TimeMessage) +"\n"
            return TimeData
        elif SetMedicine in message:
            profomat = "请设置每个药盒的药品信息：（1号药盒：药品名称，服药数量）---配置完毕后发送（药品设置完毕）"
            flagtext = 1
            return profomat
        elif boxtext in message and flagtext == 1:
            if message[0] == "1":
                if message[10] == ":":
                    if message[-2] == ",":
                        MdcineMessage[0] = message[11:][:-2]
                        MdcineMessage[1] = message[-1]
                    else:
                        MdcineMessage[0] = message[11:][:-4]
                        MdcineMessage[1] = message[-1]
                else:
                    if message[-2] == ",":
                        MdcineMessage[0] = message[13:][:-2]
                        MdcineMessage[1] = message[-1]
                    else:
                        MdcineMessage[0] = message[13:][:-4]
                        MdcineMessage[1] = message[-1]
            if message[0] == "2":
                if message[10] == ":":
                    if message[-2] == ",":
                        MdcineMessage[2] = message[11:][:-2]
                        MdcineMessage[3] = message[-1]
                    else:
                        MdcineMessage[2] = message[11:][:-4]
                        MdcineMessage[3] = message[-1]
                else:
                    if message[-2] == ",":
                        MdcineMessage[2] = message[13:][:-2]
                        MdcineMessage[3] = message[-1]
                    else:
                        MdcineMessage[2] = message[13:][:-4]
                        MdcineMessage[3] = message[-1]
            if message[0] == "3":
                if message[10] == ":":
                    if message[-2] == ",":
                        MdcineMessage[4] = message[11:][:-2]
                        MdcineMessage[5] = message[-1]
                    else:
                        MdcineMessage[4] = message[11:][:-4]
                        MdcineMessage[5] = message[-1]
                else:
                    if message[-2] == ",":
                        MdcineMessage[4] = message[13:][:-2]
                        MdcineMessage[5] = message[-1]
                    else:
                        MdcineMessage[4] = message[13:][:-4]
                        MdcineMessage[5] = message[-1]
            if message[0] == "4":
                if message[10] == ":":
                    if message[-2] == ",":
                        MdcineMessage[6] = message[11:][:-2]
                        MdcineMessage[7] = message[-1]
                    else:
                        MdcineMessage[6] = message[11:][:-4]
                        MdcineMessage[7] = message[-1]
                else:
                    if message[-2] == ",":
                        MdcineMessage[6] = message[13:][:-2]
                        MdcineMessage[7] = message[-1]
                    else:
                        MdcineMessage[6] = message[13:][:-4]
                        MdcineMessage[7] = message[-1]
            if message[0] == "5":
                if message[10] == ":":
                    if message[-2] == ",":
                        MdcineMessage[8] = message[11:][:-2]
                        MdcineMessage[9] = message[-1]
                    else:
                        MdcineMessage[8] = message[11:][:-4]
                        MdcineMessage[9] = message[-1]
                else:
                    if message[-2] == ",":
                        MdcineMessage[8] = message[13:][:-2]
                        MdcineMessage[9] = message[-1]
                    else:
                        MdcineMessage[8] = message[13:][:-4]
                        MdcineMessage[9] = message[-1]
            if message[0] == "6":
                if message[10] == ":":
                    if message[-2] == ",":
                        MdcineMessage[10] = message[11:][:-2]
                        MdcineMessage[11] = message[-1]
                    else:
                        MdcineMessage[10] = message[11:][:-4]
                        MdcineMessage[11] = message[-1]
                else:
                    if message[-2] == ",":
                        MdcineMessage[10] = message[13:][:-2]
                        MdcineMessage[11] = message[-1]
                    else:
                        MdcineMessage[10] = message[13:][:-4]
                        MdcineMessage[11] = message[-1]
            print MdcineMessage
            return message[0] + "号药盒配置完毕"
        elif "药品设置完毕" in message or "药箱信息" in message:
            flagtext = 0
            mdcinemsg = self.medicine(MdcineMessage[0], MdcineMessage[1], MdcineMessage[2],
                                      MdcineMessage[3], MdcineMessage[4], MdcineMessage[5],
                                      MdcineMessage[6], MdcineMessage[7], MdcineMessage[8],
                                      MdcineMessage[9], MdcineMessage[10], MdcineMessage[11])
            return mdcinemsg
        elif msgtext in message:
            return self.ReadMe()
        elif health in message:
            health_advice = "每日健康提醒：多做运动多喝水，根据天气情况出门活动"
            return "%s\n%s" % (self.get_whether(), health_advice)
        elif life in message:
            life_advice = "生活助手功能正在开发中，敬请期待！\n--益佳智能药箱"
            return life_advice
        elif bodydata in message:
            body_query = "智能手环功能正在开发中，敬请期待！\n--益佳智能药箱"
            return body_query
        else:
            return "益佳智能药箱"

    # 智能药箱主程序
    def cabinet(self, msg):
        global userID
        times = time.localtime()
        hour = times.tm_hour
        mines = times.tm_min
        if msg['msg_type_id'] == 4 and msg['content']['type'] == 0:
            voice_text = msg["content"]['data'].encode("utf-8")
            MessageChat = self.CabinetControl(voice_text)
            if MessageChat is not " ":
                self.send_msg_by_uid(MessageChat, msg['user']['id'])
                userID = msg['user']['id']

                # -------------------------智能药箱程序结束部分-------------------------------

    # 在未传入bot_conf的情况下尝试载入本地配置文件，WxbotManage使用
    def load_conf(self, bot_conf):
        try:
            if bot_conf == {}:
                with open(os.path.join(self.temp_pwd, 'bot_conf.json')) as f:
                    self.bot_conf = json.loads(f.read())
        except:
            self.bot_conf = {}

    # 保存配置文件，WxbotManage使用
    def save_conf(self):
        with open(os.path.join(self.temp_pwd, 'bot_conf.json'), 'w') as f:
            f.write(json.dumps(self.bot_conf))

    @staticmethod
    def to_unicode(string, encoding='utf-8'):
        """
        将字符串转换为Unicode
        :param string: 待转换字符串
        :param encoding: 字符串解码方式
        :return: 转换后的Unicode字符串
        """
        if isinstance(string, str):
            return string.decode(encoding)
        elif isinstance(string, unicode):
            return string
        else:
            raise Exception('Unknown Type')

    def get_contact(self):
        """获取当前账户的所有相关账号(包括联系人、公众号、群聊、特殊账号)"""
        dic_list = []
        url = self.base_uri + '/webwxgetcontact?seq=0&pass_ticket=%s&skey=%s&r=%s' \
                              % (self.pass_ticket, self.skey, int(time.time()))

        # 如果通讯录联系人过多，这里会直接获取失败
        try:
            r = self.session.post(url, data='{}', timeout=180)
        except Exception as e:
            return False
        r.encoding = 'utf-8'
        dic = json.loads(r.text)
        dic_list.append(dic)

        while int(dic["Seq"]) != 0:
            print "[INFO] Geting contacts. Get %s contacts for now" % dic["MemberCount"]
            url = self.base_uri + '/webwxgetcontact?seq=%s&pass_ticket=%s&skey=%s&r=%s' \
                                  % (dic["Seq"], self.pass_ticket, self.skey, int(time.time()))
            r = self.session.post(url, data='{}', timeout=180)
            r.encoding = 'utf-8'
            dic = json.loads(r.text)
            dic_list.append(dic)

        if self.DEBUG:
            with open(os.path.join(self.temp_pwd, 'contacts.json'), 'w') as f:
                f.write(json.dumps(dic_list))

        self.member_list = []
        for dic in dic_list:
            self.member_list.extend(dic['MemberList'])

        special_users = ['newsapp', 'fmessage', 'filehelper', 'weibo', 'qqmail',
                         'fmessage', 'tmessage', 'qmessage', 'qqsync', 'floatbottle',
                         'lbsapp', 'shakeapp', 'medianote', 'qqfriend', 'readerapp',
                         'blogapp', 'facebookapp', 'masssendapp', 'meishiapp',
                         'feedsapp', 'voip', 'blogappweixin', 'weixin', 'brandsessionholder',
                         'weixinreminder', 'wxid_novlwrv3lqwv11', 'gh_22b87fa7cb3c',
                         'officialaccounts', 'notification_messages', 'wxid_novlwrv3lqwv11',
                         'gh_22b87fa7cb3c', 'wxitil', 'userexperience_alarm', 'notification_messages']

        self.contact_list = []
        self.public_list = []
        self.special_list = []
        self.group_list = []

        for contact in self.member_list:
            if contact['VerifyFlag'] & 8 != 0:  # 公众号
                self.public_list.append(contact)
                self.account_info['normal_member'][contact['UserName']] = {'type': 'public', 'info': contact}
            elif contact['UserName'] in special_users:  # 特殊账户
                self.special_list.append(contact)
                self.account_info['normal_member'][contact['UserName']] = {'type': 'special', 'info': contact}
            elif contact['UserName'].find('@@') != -1:  # 群聊
                self.group_list.append(contact)
                self.account_info['normal_member'][contact['UserName']] = {'type': 'group', 'info': contact}
            elif contact['UserName'] == self.my_account['UserName']:  # 自己
                self.account_info['normal_member'][contact['UserName']] = {'type': 'self', 'info': contact}
            else:
                self.contact_list.append(contact)
                self.account_info['normal_member'][contact['UserName']] = {'type': 'contact', 'info': contact}

        self.batch_get_group_members()

        for group in self.group_members:
            for member in self.group_members[group]:
                if member['UserName'] not in self.account_info:
                    self.account_info['group_member'][member['UserName']] = \
                        {'type': 'group_member', 'info': member, 'group': group}

        if self.DEBUG:
            with open(os.path.join(self.temp_pwd, 'contact_list.json'), 'w') as f:
                f.write(json.dumps(self.contact_list))
            with open(os.path.join(self.temp_pwd, 'special_list.json'), 'w') as f:
                f.write(json.dumps(self.special_list))
            with open(os.path.join(self.temp_pwd, 'group_list.json'), 'w') as f:
                f.write(json.dumps(self.group_list))
            with open(os.path.join(self.temp_pwd, 'public_list.json'), 'w') as f:
                f.write(json.dumps(self.public_list))
            with open(os.path.join(self.temp_pwd, 'member_list.json'), 'w') as f:
                f.write(json.dumps(self.member_list))
            with open(os.path.join(self.temp_pwd, 'group_users.json'), 'w') as f:
                f.write(json.dumps(self.group_members))
            with open(os.path.join(self.temp_pwd, 'account_info.json'), 'w') as f:
                f.write(json.dumps(self.account_info))
        return True

    def get_big_contact(self):
        total_len = len(self.full_user_name_list)
        user_info_list = []

        # 一次拉取50个联系人的信息，包括所有的群聊，公众号，好友
        while self.cursor < total_len:
            cur_batch = self.full_user_name_list[self.cursor:(self.cursor + self.batch_count)]
            self.cursor += self.batch_count
            cur_batch = map(map_username_batch, cur_batch)
            user_info_list += self.batch_get_contact(cur_batch)
            print "[INFO] Get batch contacts"

        self.member_list = user_info_list
        special_users = ['newsapp', 'filehelper', 'weibo', 'qqmail',
                         'fmessage', 'tmessage', 'qmessage', 'qqsync', 'floatbottle',
                         'lbsapp', 'shakeapp', 'medianote', 'qqfriend', 'readerapp',
                         'blogapp', 'facebookapp', 'masssendapp', 'meishiapp',
                         'feedsapp', 'voip', 'blogappweixin', 'weixin', 'brandsessionholder',
                         'weixinreminder', 'wxid_novlwrv3lqwv11',
                         'officialaccounts',
                         'gh_22b87fa7cb3c', 'wxitil', 'userexperience_alarm', 'notification_messages', 'notifymessage']

        self.contact_list = []
        self.public_list = []
        self.special_list = []
        self.group_list = []
        for i, contact in enumerate(self.member_list):
            if contact['VerifyFlag'] & 8 != 0:  # 公众号
                self.public_list.append(contact)
                self.account_info['normal_member'][contact['UserName']] = {'type': 'public', 'info': contact}
            elif contact['UserName'] in special_users or self.wxid_list[i] in special_users:  # 特殊账户
                self.special_list.append(contact)
                self.account_info['normal_member'][contact['UserName']] = {'type': 'special', 'info': contact}
            elif contact['UserName'].find('@@') != -1:  # 群聊
                self.group_list.append(contact)
                self.account_info['normal_member'][contact['UserName']] = {'type': 'group', 'info': contact}
            elif contact['UserName'] == self.my_account['UserName']:  # 自己
                self.account_info['normal_member'][contact['UserName']] = {'type': 'self', 'info': contact}
            else:
                self.contact_list.append(contact)
                self.account_info['normal_member'][contact['UserName']] = {'type': 'contact', 'info': contact}
        group_members = {}
        encry_chat_room_id = {}
        for group in self.group_list:
            gid = group['UserName']
            members = group['MemberList']
            group_members[gid] = members
            encry_chat_room_id[gid] = group['EncryChatRoomId']
        self.group_members = group_members
        self.encry_chat_room_id_list = encry_chat_room_id

        for group in self.group_members:
            for member in self.group_members[group]:
                if member['UserName'] not in self.account_info:
                    self.account_info['group_member'][member['UserName']] = \
                        {'type': 'group_member', 'info': member, 'group': group}

        if self.DEBUG:
            with open(os.path.join(self.temp_pwd, 'contact_list.json'), 'w') as f:
                f.write(json.dumps(self.contact_list))
            with open(os.path.join(self.temp_pwd, 'special_list.json'), 'w') as f:
                f.write(json.dumps(self.special_list))
            with open(os.path.join(self.temp_pwd, 'group_list.json'), 'w') as f:
                f.write(json.dumps(self.group_list))
            with open(os.path.join(self.temp_pwd, 'public_list.json'), 'w') as f:
                f.write(json.dumps(self.public_list))
            with open(os.path.join(self.temp_pwd, 'member_list.json'), 'w') as f:
                f.write(json.dumps(self.member_list))
            with open(os.path.join(self.temp_pwd, 'group_users.json'), 'w') as f:
                f.write(json.dumps(self.group_members))
            with open(os.path.join(self.temp_pwd, 'account_info.json'), 'w') as f:
                f.write(json.dumps(self.account_info))
        print '[INFO] Get %d contacts' % len(self.contact_list)
        print '[INFO] Start to process messages .'
        return True

    def batch_get_contact(self, cur_batch):
        """批量获取成员信息"""
        url = self.base_uri + '/webwxbatchgetcontact?type=ex&r=%s&pass_ticket=%s' % (int(time.time()), self.pass_ticket)
        params = {
            'BaseRequest': self.base_request,
            "Count": len(cur_batch),
            "List": cur_batch
        }
        r = self.session.post(url, data=json.dumps(params))
        r.encoding = 'utf-8'
        dic = json.loads(r.text)
        # print dic['ContactList']
        return dic['ContactList']

    def batch_get_group_members(self):
        """批量获取所有群聊成员信息"""
        url = self.base_uri + '/webwxbatchgetcontact?type=ex&r=%s&pass_ticket=%s' % (int(time.time()), self.pass_ticket)
        params = {
            'BaseRequest': self.base_request,
            "Count": len(self.group_list),
            "List": [{"UserName": group['UserName'], "EncryChatRoomId": ""} for group in self.group_list]
        }
        r = self.session.post(url, data=json.dumps(params))
        r.encoding = 'utf-8'
        dic = json.loads(r.text)
        group_members = {}
        encry_chat_room_id = {}
        for group in dic['ContactList']:
            gid = group['UserName']
            members = group['MemberList']
            group_members[gid] = members
            encry_chat_room_id[gid] = group['EncryChatRoomId']
        self.group_members = group_members
        self.encry_chat_room_id_list = encry_chat_room_id

    def get_group_member_name(self, gid, uid):
        """
        获取群聊中指定成员的名称信息
        :param gid: 群id
        :param uid: 群聊成员id
        :return: 名称信息，类似 {"display_name": "test_user", "nickname": "test", "remark_name": "for_test" }
        """
        if gid not in self.group_members:
            return None
        group = self.group_members[gid]
        for member in group:
            if member['UserName'] == uid:
                names = {}
                if 'RemarkName' in member and member['RemarkName']:
                    names['remark_name'] = member['RemarkName']
                if 'NickName' in member and member['NickName']:
                    names['nickname'] = member['NickName']
                if 'DisplayName' in member and member['DisplayName']:
                    names['display_name'] = member['DisplayName']
                return names
        return None

    def get_contact_info(self, uid):
        return self.account_info['normal_member'].get(uid)

    def get_group_member_info(self, uid):
        return self.account_info['group_member'].get(uid)

    def get_contact_name(self, uid):
        info = self.get_contact_info(uid)
        if info is None:
            return None
        info = info['info']
        name = {}
        if 'RemarkName' in info and info['RemarkName']:
            name['remark_name'] = info['RemarkName']
        if 'NickName' in info and info['NickName']:
            name['nickname'] = info['NickName']
        if 'DisplayName' in info and info['DisplayName']:
            name['display_name'] = info['DisplayName']
        if len(name) == 0:
            return None
        else:
            return name

    @staticmethod
    def get_contact_prefer_name(name):
        if name is None:
            return None
        if 'remark_name' in name:
            return name['remark_name']
        if 'nickname' in name:
            return name['nickname']
        if 'display_name' in name:
            return name['display_name']
        return None

    @staticmethod
    def get_group_member_prefer_name(name):
        if name is None:
            return None
        if 'remark_name' in name:
            return name['remark_name']
        if 'display_name' in name:
            return name['display_name']
        if 'nickname' in name:
            return name['nickname']
        return None

    def get_user_type(self, wx_user_id):
        """
        获取特定账号与自己的关系
        :param wx_user_id: 账号id:
        :return: 与当前账号的关系
        """
        for account in self.contact_list:
            if wx_user_id == account['UserName']:
                return 'contact'
        for account in self.public_list:
            if wx_user_id == account['UserName']:
                return 'public'
        for account in self.special_list:
            if wx_user_id == account['UserName']:
                return 'special'
        for account in self.group_list:
            if wx_user_id == account['UserName']:
                return 'group'
        for group in self.group_members:
            for member in self.group_members[group]:
                if member['UserName'] == wx_user_id:
                    return 'group_member'
        return 'unknown'

    def is_contact(self, uid):
        for account in self.contact_list:
            if uid == account['UserName']:
                return True
        return False

    def is_public(self, uid):
        for account in self.public_list:
            if uid == account['UserName']:
                return True
        return False

    def is_special(self, uid):
        for account in self.special_list:
            if uid == account['UserName']:
                return True
        return False

    def handle_msg_all(self, msg):
        """
        处理所有消息，请子类化后覆盖此函数
        msg:
            msg_id  ->  消息id
            msg_type_id  ->  消息类型id
            user  ->  发送消息的账号id
            content  ->  消息内容
        :param msg: 收到的消息
        """
        pass

    @staticmethod
    def proc_at_info(msg):
        if not msg:
            return '', []
        segs = msg.split(u'\u2005')
        str_msg_all = ''
        str_msg = ''
        infos = []
        if len(segs) > 1:
            for i in range(0, len(segs) - 1):
                segs[i] += u'\u2005'
                pm = re.search(u'@.*\u2005', segs[i]).group()
                if pm:
                    name = pm[1:-1]
                    string = segs[i].replace(pm, '')
                    str_msg_all += string + '@' + name + ' '
                    str_msg += string
                    if string:
                        infos.append({'type': 'str', 'value': string})
                    infos.append({'type': 'at', 'value': name})
                else:
                    infos.append({'type': 'str', 'value': segs[i]})
                    str_msg_all += segs[i]
                    str_msg += segs[i]
            str_msg_all += segs[-1]
            str_msg += segs[-1]
            infos.append({'type': 'str', 'value': segs[-1]})
        else:
            infos.append({'type': 'str', 'value': segs[-1]})
            str_msg_all = msg
            str_msg = msg
        return str_msg_all.replace(u'\u2005', ''), str_msg.replace(u'\u2005', ''), infos

    def extract_msg_content(self, msg_type_id, msg):
        """
        content_type_id:
            0 -> Text
            1 -> Location
            3 -> Image
            4 -> Voice
            5 -> Recommend
            6 -> Animation
            7 -> Share
            8 -> Video
            9 -> VideoCall
            10 -> Redraw
            11 -> Empty
            99 -> Unknown
        :param msg_type_id: 消息类型id
        :param msg: 消息结构体
        :return: 解析的消息
        """
        mtype = msg['MsgType']
        content = HTMLParser.HTMLParser().unescape(msg['Content'])
        msg_id = msg['MsgId']

        msg_content = {}
        if msg_type_id == 0:
            return {'type': 11, 'data': ''}
        elif msg_type_id == 2:  # File Helper
            return {'type': 0, 'data': content.replace('<br/>', '\n')}
        elif msg_type_id == 3:  # 群聊
            sp = content.find('<br/>')
            uid = content[:sp]
            content = content[sp:]
            content = content.replace('<br/>', '')
            uid = uid[:-1]
            name = self.get_contact_prefer_name(self.get_contact_name(uid))
            if not name:
                name = self.get_group_member_prefer_name(self.get_group_member_name(msg['FromUserName'], uid))
            if not name:
                name = 'unknown'
            msg_content['user'] = {'id': uid, 'name': name}
        else:  # Self, Contact, Special, Public, Unknown
            pass

        msg_prefix = (msg_content['user']['name'] + ':') if 'user' in msg_content else ''

        if mtype == 1:
            if content.find('http://weixin.qq.com/cgi-bin/redirectforward?args=') != -1:
                r = self.session.get(content)
                r.encoding = 'gbk'
                data = r.text
                pos = self.search_content('title', data, 'xml')
                msg_content['type'] = 1
                msg_content['data'] = pos
                msg_content['detail'] = data
                if self.DEBUG:
                    print '    %s[Location] %s ' % (msg_prefix, pos)
            else:
                msg_content['type'] = 0
                if msg_type_id == 3 or (msg_type_id == 1 and msg['ToUserName'][:2] == '@@'):  # Group text message
                    msg_infos = self.proc_at_info(content)
                    str_msg_all = msg_infos[0]
                    str_msg = msg_infos[1]
                    detail = msg_infos[2]
                    msg_content['data'] = str_msg_all
                    msg_content['detail'] = detail
                    msg_content['desc'] = str_msg
                else:
                    msg_content['data'] = content
                if self.DEBUG:
                    try:
                        print '    %s[Text] %s' % (msg_prefix, msg_content['data'])
                    except UnicodeEncodeError:
                        print '    %s[Text] (illegal text).' % msg_prefix
        elif mtype == 3:
            msg_content['type'] = 3
            msg_content['data'] = self.get_msg_img_url(msg_id)
            msg_content['img'] = self.session.get(msg_content['data']).content.encode('hex')
            if self.DEBUG:
                image = self.get_msg_img(msg_id)
                print '    %s[Image] %s' % (msg_prefix, image)
        elif mtype == 34:
            msg_content['type'] = 4
            msg_content['data'] = self.get_voice_url(msg_id)
            msg_content['voice'] = self.session.get(msg_content['data']).content.encode('hex')
            if self.DEBUG:
                voice = self.get_voice(msg_id)
                print '    %s[Voice] %s' % (msg_prefix, voice)
        elif mtype == 37:
            msg_content['type'] = 37
            msg_content['data'] = msg['RecommendInfo']
            if self.DEBUG:
                print '    %s[useradd] %s' % (msg_prefix, msg['RecommendInfo']['NickName'])
        elif mtype == 42:
            msg_content['type'] = 5
            info = msg['RecommendInfo']
            msg_content['data'] = {'nickname': info['NickName'],
                                   'alias': info['Alias'],
                                   'province': info['Province'],
                                   'city': info['City'],
                                   'gender': ['unknown', 'male', 'female'][info['Sex']]}
            if self.DEBUG:
                print '    %s[Recommend]' % msg_prefix
                print '    -----------------------------'
                print '    | NickName: %s' % info['NickName']
                print '    | Alias: %s' % info['Alias']
                print '    | Local: %s %s' % (info['Province'], info['City'])
                print '    | Gender: %s' % ['unknown', 'male', 'female'][info['Sex']]
                print '    -----------------------------'
        elif mtype == 47:
            msg_content['type'] = 6
            msg_content['data'] = self.search_content('cdnurl', content)
            if self.DEBUG:
                print '    %s[Animation] %s' % (msg_prefix, msg_content['data'])
        elif mtype == 49:
            msg_content['type'] = 7
            if msg['AppMsgType'] == 3:
                app_msg_type = 'music'
            elif msg['AppMsgType'] == 5:
                app_msg_type = 'link'
            elif msg['AppMsgType'] == 7:
                app_msg_type = 'weibo'
            else:
                app_msg_type = 'unknown'
            msg_content['data'] = {'type': app_msg_type,
                                   'title': msg['FileName'],
                                   'desc': self.search_content('des', content, 'xml'),
                                   'url': msg['Url'],
                                   'from': self.search_content('appname', content, 'xml'),
                                   'content': msg.get('Content')  # 有的公众号会发一次性3 4条链接一个大图,如果只url那只能获取第一条,content里面有所有的链接
                                   }
            if self.DEBUG:
                print '    %s[Share] %s' % (msg_prefix, app_msg_type)
                print '    --------------------------'
                print '    | title: %s' % msg['FileName']
                print '    | desc: %s' % self.search_content('des', content, 'xml')
                print '    | link: %s' % msg['Url']
                print '    | from: %s' % self.search_content('appname', content, 'xml')
                print '    | content: %s' % (msg.get('content')[:20] if msg.get('content') else "unknown")
                print '    --------------------------'

        elif mtype == 62:
            msg_content['type'] = 8
            msg_content['data'] = content
            if self.DEBUG:
                print '    %s[Video] Please check on mobiles' % msg_prefix
        elif mtype == 53:
            msg_content['type'] = 9
            msg_content['data'] = content
            if self.DEBUG:
                print '    %s[Video Call]' % msg_prefix
        elif mtype == 10002:
            msg_content['type'] = 10
            msg_content['data'] = content
            if self.DEBUG:
                print '    %s[Redraw]' % msg_prefix
        elif mtype == 10000:  # unknown, maybe red packet, or group invite
            msg_content['type'] = 12
            msg_content['data'] = msg['Content']
            if self.DEBUG:
                print '    [Unknown]'
        elif mtype == 43:
            msg_content['type'] = 13
            msg_content['data'] = self.get_video_url(msg_id)
            if self.DEBUG:
                print '    %s[video] %s' % (msg_prefix, msg_content['data'])
        else:
            msg_content['type'] = 99
            msg_content['data'] = content
            if self.DEBUG:
                print '    %s[Unknown]' % msg_prefix
        return msg_content

    def handle_msg(self, r):
        """
        处理原始微信消息的内部函数
        msg_type_id:
            0 -> Init
            1 -> Self
            2 -> FileHelper
            3 -> Group
            4 -> Contact
            5 -> Public
            6 -> Special
            99 -> Unknown
        :param r: 原始微信消息
        """
        for msg in r['AddMsgList']:
            user = {'id': msg['FromUserName'], 'name': 'unknown'}
            if msg['MsgType'] == 51 and msg['StatusNotifyCode'] == 4:  # init message
                msg_type_id = 0
                user['name'] = 'system'
                # 会获取所有联系人的username 和 wxid，但是会收到3次这个消息，只取第一次
                if self.is_big_contact and len(self.full_user_name_list) == 0:
                    self.full_user_name_list = msg['StatusNotifyUserName'].split(",")
                    self.wxid_list = re.search(r"username&gt;(.*?)&lt;/username", msg["Content"]).group(1).split(",")
                    with open(os.path.join(self.temp_pwd, 'UserName.txt'), 'w') as f:
                        f.write(msg['StatusNotifyUserName'])
                    with open(os.path.join(self.temp_pwd, 'wxid.txt'), 'w') as f:
                        f.write(json.dumps(self.wxid_list))
                    print "[INFO] Contact list is too big. Now start to fetch member list ."
                    # self.get_big_contact()

            elif msg['MsgType'] == 37:  # friend request
                msg_type_id = 37
                pass
                # content = msg['Content']
                # username = content[content.index('fromusername='): content.index('encryptusername')]
                # username = username[username.index('"') + 1: username.rindex('"')]
                # print u'[Friend Request]'
                # print u'       Nickname：' + msg['RecommendInfo']['NickName']
                # print u'       附加消息：'+msg['RecommendInfo']['Content']
                # # print u'Ticket：'+msg['RecommendInfo']['Ticket'] # Ticket添加好友时要用
                # print u'       微信号：'+username #未设置微信号的 腾讯会自动生成一段微信ID 但是无法通过搜索 搜索到此人
            elif msg['FromUserName'] == self.my_account['UserName']:  # Self
                msg_type_id = 1
                user['name'] = 'self'
            elif msg['ToUserName'] == 'filehelper':  # File Helper
                msg_type_id = 2
                user['name'] = 'file_helper'
            elif msg['FromUserName'][:2] == '@@':  # Group
                msg_type_id = 3
                user['name'] = self.get_contact_prefer_name(self.get_contact_name(user['id']))
            elif self.is_contact(msg['FromUserName']):  # Contact
                msg_type_id = 4
                user['name'] = self.get_contact_prefer_name(self.get_contact_name(user['id']))
            elif self.is_public(msg['FromUserName']):  # Public
                msg_type_id = 5
                user['name'] = self.get_contact_prefer_name(self.get_contact_name(user['id']))
            elif self.is_special(msg['FromUserName']):  # Special
                msg_type_id = 6
                user['name'] = self.get_contact_prefer_name(self.get_contact_name(user['id']))
            else:
                msg_type_id = 99
                user['name'] = 'unknown'
            if not user['name']:
                user['name'] = 'unknown'
            user['name'] = HTMLParser.HTMLParser().unescape(user['name'])

            if self.DEBUG and msg_type_id != 0:
                print u'[MSG] %s:' % user['name']
            content = self.extract_msg_content(msg_type_id, msg)
            message = {'msg_type_id': msg_type_id,
                       'msg_id': msg['MsgId'],
                       'content': content,
                       'to_user_id': msg['ToUserName'],
                       'user': user}
            self.cabinet(message)

    def schedule(self):
        """
        做任务型事情的函数，如果需要，可以在子类中覆盖此函数
        此函数在处理消息的间隙被调用，请不要长时间阻塞此函数
        """
        global TimeHour, TimeMin
        times = time.localtime()
        hour = times.tm_hour
        mines = times.tm_min
        sec = times.tm_sec
        for num in range(0, len(TimeDictionary)):
            num = num + 1
            chinesenumber = {1: "一", 2: "二", 3: "三", 4: "四", 5: "五"}
            TimeMessage = TimeDictionary[chinesenumber[num]]
            if TimeMessage[2] is ':':
                TimeMin = "%s%s" % (TimeMessage[3], TimeMessage[4])
                TimeHour = "%s%s" % (TimeMessage[0], TimeMessage[1])
            elif TimeMessage[1] is ':':
                TimeMin = "%s%s" % (TimeMessage[2], TimeMessage[3])
                TimeHour = "%s" % (TimeMessage[0])
            else:
                if len(TimeMessage) == 7:
                    TimeMin = "%s%s" % (TimeMessage[5], TimeMessage[6])
                    TimeHour = "%s%s" % (TimeMessage[0], TimeMessage[1])
                else:
                    TimeMin = "%s%s" % (TimeMessage[4], TimeMessage[5])
                    TimeHour = "%s" % (TimeMessage[0])
            if hour == int(TimeHour):
                if mines == int(TimeMin):
                    Mdeication_remind = "第%s次分药开始，请准备服药"%chinesenumber[num]
                    self.send_msg('H77', Mdeication_remind)
                    time.sleep(60)

    def proc_msg(self):
        self.test_sync_check()
        self.status = 'loginsuccess'  # WxbotManage使用
        while True:
            if self.status == 'wait4loginout':  # WxbotManage使用
                return
            check_time = time.time()
            try:
                [retcode, selector] = self.sync_check()
                # print '[DEBUG] sync_check:', retcode, selector
                if retcode == '1100':  # 从微信客户端上登出
                    break
                elif retcode == '1101':  # 从其它设备上登了网页微信
                    break
                elif retcode == '0':
                    if selector == '2':  # 有新消息
                        r = self.sync()
                        if r is not None:
                            self.handle_msg(r)
                    elif selector == '3':  # 未知
                        r = self.sync()
                        if r is not None:
                            self.handle_msg(r)
                    elif selector == '4':  # 通讯录更新
                        r = self.sync()
                        if r is not None:
                            self.get_contact()
                    elif selector == '6':  # 可能是红包
                        r = self.sync()
                        if r is not None:
                            self.handle_msg(r)
                    elif selector == '7':  # 在手机上操作了微信
                        r = self.sync()
                        if r is not None:
                            self.handle_msg(r)
                    elif selector == '0':  # 无事件
                        pass
                    else:
                        print '[DEBUG] sync_check:', retcode, selector
                        r = self.sync()
                        if r is not None:
                            self.handle_msg(r)
                else:
                    print '[DEBUG] sync_check:', retcode, selector
                    time.sleep(10)
                self.schedule()
            except:
                print '[ERROR] Except in proc_msg'
                print format_exc()
            check_time = time.time() - check_time
            if check_time < 0.8:
                time.sleep(1 - check_time)

    def apply_useradd_requests(self, RecommendInfo):
        url = self.base_uri + '/webwxverifyuser?r=' + str(int(time.time())) + '&lang=zh_CN'
        params = {
            "BaseRequest": self.base_request,
            "Opcode": 3,
            "VerifyUserListSize": 1,
            "VerifyUserList": [
                {
                    "Value": RecommendInfo['UserName'],
                    "VerifyUserTicket": RecommendInfo['Ticket']}
            ],
            "VerifyContent": "",
            "SceneListCount": 1,
            "SceneList": [
                33
            ],
            "skey": self.skey
        }
        headers = {'content-type': 'application/json; charset=UTF-8'}
        data = json.dumps(params, ensure_ascii=False).encode('utf8')
        try:
            r = self.session.post(url, data=data, headers=headers)
        except (ConnectionError, ReadTimeout):
            return False
        dic = r.json()
        return dic['BaseResponse']['Ret'] == 0

    def add_groupuser_to_friend_by_uid(self, uid, VerifyContent):
        """
        主动向群内人员打招呼，提交添加好友请求
        uid-群内人员得uid   VerifyContent-好友招呼内容
        慎用此接口！封号后果自负！慎用此接口！封号后果自负！慎用此接口！封号后果自负！
        """
        if self.is_contact(uid):
            return True
        url = self.base_uri + '/webwxverifyuser?r=' + str(int(time.time())) + '&lang=zh_CN'
        params = {
            "BaseRequest": self.base_request,
            "Opcode": 2,
            "VerifyUserListSize": 1,
            "VerifyUserList": [
                {
                    "Value": uid,
                    "VerifyUserTicket": ""
                }
            ],
            "VerifyContent": VerifyContent,
            "SceneListCount": 1,
            "SceneList": [
                33
            ],
            "skey": self.skey
        }
        headers = {'content-type': 'application/json; charset=UTF-8'}
        data = json.dumps(params, ensure_ascii=False).encode('utf8')
        try:
            r = self.session.post(url, data=data, headers=headers)
        except (ConnectionError, ReadTimeout):
            return False
        dic = r.json()
        return dic['BaseResponse']['Ret'] == 0

    def add_friend_to_group(self, uid, group_name):
        """
        将好友加入到群聊中
        """
        gid = ''
        # 　通过群名获取群id,群没保存到通讯录中的话无法添加哦
        for group in self.group_list:
            if group['NickName'] == group_name:
                gid = group['UserName']
        if gid == '':
            return False
        # 获取群成员数量并判断邀请方式
        group_num = len(self.group_members[gid])
        print '[DEBUG] group_name:%s group_num:%s' % (group_name, group_num)
        # 　通过群id判断uid是否在群中
        for user in self.group_members[gid]:
            if user['UserName'] == uid:
                # 　已经在群里面了,不用加了
                return True
        if group_num <= 100:
            url = self.base_uri + '/webwxupdatechatroom?fun=addmember&pass_ticket=%s' % self.pass_ticket
            params = {
                "AddMemberList": uid,
                "ChatRoomName": gid,
                "BaseRequest": self.base_request
            }
        else:
            url = self.base_uri + '/webwxupdatechatroom?fun=invitemember'
            params = {
                "InviteMemberList": uid,
                "ChatRoomName": gid,
                "BaseRequest": self.base_request
            }
        headers = {'content-type': 'application/json; charset=UTF-8'}
        data = json.dumps(params, ensure_ascii=False).encode('utf8')
        try:
            r = self.session.post(url, data=data, headers=headers)
        except (ConnectionError, ReadTimeout):
            return False
        dic = r.json()
        return dic['BaseResponse']['Ret'] == 0

    def invite_friend_to_group(self, uid, group_name):
        """
        将好友加入到群中。对人数多的群，需要调用此方法。
        拉人时，可以先尝试使用add_friend_to_group方法，当调用失败(Ret=1)时，再尝试调用此方法。
        """
        gid = ''
        # 通过群名获取群id,群没保存到通讯录中的话无法添加哦
        for group in self.group_list:
            if group['NickName'] == group_name:
                gid = group['UserName']
        if gid == '':
            return False
        # 通过群id判断uid是否在群中
        for user in self.group_members[gid]:
            if user['UserName'] == uid:
                # 已经在群里面了,不用加了
                return True
        url = self.base_uri + '/webwxupdatechatroom?fun=invitemember&pass_ticket=%s' % self.pass_ticket
        params = {
            "InviteMemberList": uid,
            "ChatRoomName": gid,
            "BaseRequest": self.base_request
        }
        headers = {'content-type': 'application/json; charset=UTF-8'}
        data = json.dumps(params, ensure_ascii=False).encode('utf8')
        try:
            r = self.session.post(url, data=data, headers=headers)
        except (ConnectionError, ReadTimeout):
            return False
        dic = r.json()
        return dic['BaseResponse']['Ret'] == 0

    def delete_user_from_group(self, uname, gid):
        """
        将群用户从群中剔除，只有群管理员有权限
        """
        uid = ""
        for user in self.group_members[gid]:
            if user['NickName'] == uname:
                uid = user['UserName']
        if uid == "":
            return False
        url = self.base_uri + '/webwxupdatechatroom?fun=delmember&pass_ticket=%s' % self.pass_ticket
        params = {
            "DelMemberList": uid,
            "ChatRoomName": gid,
            "BaseRequest": self.base_request
        }
        headers = {'content-type': 'application/json; charset=UTF-8'}
        data = json.dumps(params, ensure_ascii=False).encode('utf8')
        try:
            r = self.session.post(url, data=data, headers=headers)
        except (ConnectionError, ReadTimeout):
            return False
        dic = r.json()
        return dic['BaseResponse']['Ret'] == 0

    def set_group_name(self, gid, gname):
        """
        设置群聊名称
        """
        url = self.base_uri + '/webwxupdatechatroom?fun=modtopic&pass_ticket=%s' % self.pass_ticket
        params = {
            "NewTopic": gname,
            "ChatRoomName": gid,
            "BaseRequest": self.base_request
        }
        headers = {'content-type': 'application/json; charset=UTF-8'}
        data = json.dumps(params, ensure_ascii=False).encode('utf8')
        try:
            r = self.session.post(url, data=data, headers=headers)
        except (ConnectionError, ReadTimeout):
            return False
        dic = r.json()
        return dic['BaseResponse']['Ret'] == 0

    def send_msg_by_uid(self, word, dst='filehelper'):
        url = self.base_uri + '/webwxsendmsg?pass_ticket=%s' % self.pass_ticket
        msg_id = str(int(time.time() * 1000)) + str(random.random())[:5].replace('.', '')
        word = self.to_unicode(word)
        params = {
            'BaseRequest': self.base_request,
            'Msg': {
                "Type": 1,
                "Content": word,
                "FromUserName": self.my_account['UserName'],
                "ToUserName": dst,
                "LocalID": msg_id,
                "ClientMsgId": msg_id
            }
        }
        headers = {'content-type': 'application/json; charset=UTF-8'}
        data = json.dumps(params, ensure_ascii=False).encode('utf8')
        try:
            r = self.session.post(url, data=data, headers=headers)
        except (ConnectionError, ReadTimeout):
            return False
        dic = r.json()
        return dic['BaseResponse']['Ret'] == 0

    def upload_media(self, fpath, is_img=False):
        if not os.path.exists(fpath):
            print '[ERROR] File not exists.'
            return None
        url_1 = 'https://file.' + self.base_host + '/cgi-bin/mmwebwx-bin/webwxuploadmedia?f=json'
        url_2 = 'https://file2.' + self.base_host + '/cgi-bin/mmwebwx-bin/webwxuploadmedia?f=json'
        flen = str(os.path.getsize(fpath))
        ftype = mimetypes.guess_type(fpath)[0] or 'application/octet-stream'
        files = {
            'id': (None, 'WU_FILE_%s' % str(self.file_index)),
            'name': (None, os.path.basename(fpath)),
            'type': (None, ftype),
            'lastModifiedDate': (None, time.strftime('%m/%d/%Y, %H:%M:%S GMT+0800 (CST)')),
            'size': (None, flen),
            'mediatype': (None, 'pic' if is_img else 'doc'),
            'uploadmediarequest': (None, json.dumps({
                'BaseRequest': self.base_request,
                'ClientMediaId': int(time.time()),
                'TotalLen': flen,
                'StartPos': 0,
                'DataLen': flen,
                'MediaType': 4,
            })),
            'webwx_data_ticket': (None, self.session.cookies['webwx_data_ticket']),
            'pass_ticket': (None, self.pass_ticket),
            'filename': (os.path.basename(fpath), open(fpath, 'rb'), ftype.split('/')[1]),
        }
        self.file_index += 1
        try:
            r = self.session.post(url_1, files=files)
            if json.loads(r.text)['BaseResponse']['Ret'] != 0:
                # 当file返回值不为0时则为上传失败，尝试第二服务器上传
                r = self.session.post(url_2, files=files)
            if json.loads(r.text)['BaseResponse']['Ret'] != 0:
                print '[ERROR] Upload media failure.'
                return None
            mid = json.loads(r.text)['MediaId']
            return mid
        except Exception, e:
            return None

    def send_file_msg_by_uid(self, fpath, uid):
        mid = self.upload_media(fpath)
        if mid is None or not mid:
            return False
        url = self.base_uri + '/webwxsendappmsg?fun=async&f=json&pass_ticket=' + self.pass_ticket
        msg_id = str(int(time.time() * 1000)) + str(random.random())[:5].replace('.', '')
        data = {
            'BaseRequest': self.base_request,
            'Msg': {
                'Type': 6,
                'Content': (
                    "<appmsg appid='wxeb7ec651dd0aefa9' sdkver=''><title>%s</title><des></des><action></action><type>6</type><content></content><url></url><lowurl></lowurl><appattach><totallen>%s</totallen><attachid>%s</attachid><fileext>%s</fileext></appattach><extinfo></extinfo></appmsg>" % (
                        os.path.basename(fpath).encode('utf-8'), str(os.path.getsize(fpath)), mid,
                        fpath.split('.')[-1])).encode('utf8'),
                'FromUserName': self.my_account['UserName'],
                'ToUserName': uid,
                'LocalID': msg_id,
                'ClientMsgId': msg_id, }, }
        try:
            r = self.session.post(url, data=json.dumps(data))
            res = json.loads(r.text)
            if res['BaseResponse']['Ret'] == 0:
                return True
            else:
                return False
        except Exception, e:
            return False

    def send_img_msg_by_uid(self, fpath, uid):
        mid = self.upload_media(fpath, is_img=True)
        if mid is None:
            return False
        url = self.base_uri + '/webwxsendmsgimg?fun=async&f=json'
        data = {
            'BaseRequest': self.base_request,
            'Msg': {
                'Type': 3,
                'MediaId': mid,
                'FromUserName': self.my_account['UserName'],
                'ToUserName': uid,
                'LocalID': str(time.time() * 1e7),
                'ClientMsgId': str(time.time() * 1e7), }, }
        if fpath[-4:] == '.gif':
            url = self.base_uri + '/webwxsendemoticon?fun=sys'
            data['Msg']['Type'] = 47
            data['Msg']['EmojiFlag'] = 2
        try:
            r = self.session.post(url, data=json.dumps(data))
            res = json.loads(r.text)
            if res['BaseResponse']['Ret'] == 0:
                return True
            else:
                return False
        except Exception, e:
            return False

    def get_user_id(self, name):
        if name == '':
            return None
        name = self.to_unicode(name)
        for contact in self.contact_list:
            if 'RemarkName' in contact and contact['RemarkName'] == name:
                return contact['UserName']
            elif 'NickName' in contact and contact['NickName'] == name:
                return contact['UserName']
            elif 'DisplayName' in contact and contact['DisplayName'] == name:
                return contact['UserName']
        for group in self.group_list:
            if 'RemarkName' in group and group['RemarkName'] == name:
                return group['UserName']
            if 'NickName' in group and group['NickName'] == name:
                return group['UserName']
            if 'DisplayName' in group and group['DisplayName'] == name:
                return group['UserName']

        return ''

    def send_msg(self, name, word, isfile=False):
        uid = self.get_user_id(name)
        if uid is not None:
            if isfile:
                with open(word, 'r') as f:
                    result = True
                    for line in f.readlines():
                        line = line.replace('\n', '')
                        print '-> ' + name + ': ' + line
                        if self.send_msg_by_uid(line, uid):
                            pass
                        else:
                            result = False
                        time.sleep(1)
                    return result
            else:
                word = self.to_unicode(word)
                if self.send_msg_by_uid(word, uid):
                    return True
                else:
                    return False
        else:
            if self.DEBUG:
                print '[ERROR] This user does not exist .'
            return True

    @staticmethod
    def search_content(key, content, fmat='attr'):
        if fmat == 'attr':
            pm = re.search(key + '\s?=\s?"([^"<]+)"', content)
            if pm:
                return pm.group(1)
        elif fmat == 'xml':
            pm = re.search('<{0}>([^<]+)</{0}>'.format(key), content)
            if pm:
                return pm.group(1)
        return 'unknown'

    def run(self):
        try:
            self.get_uuid()
            self.gen_qr_code(os.path.join(self.temp_pwd, 'wxqr.png'))
            print '[INFO] Please use WeChat to scan the QR code .'

            result = self.wait4login()
            if result != SUCCESS:
                print '[ERROR] Web WeChat login failed. failed code=%s' % (result,)
                self.status = 'loginout'
                return

            if self.login():
                print '[INFO] Web WeChat login succeed .'
            else:
                print '[ERROR] Web WeChat login failed .'
                self.status = 'loginout'
                return

            if self.init():
                print '[INFO] Web WeChat init succeed .'
            else:
                print '[INFO] Web WeChat init failed'
                self.status = 'loginout'
                return
            self.status_notify()
            if self.get_contact():
                print '[INFO] Get %d contacts' % len(self.contact_list)
                print '[INFO] Start to process messages .'
            self.proc_msg()
            self.status = 'loginout'
        except Exception, e:
            print '[ERROR] Web WeChat run failed --> %s' % (e)
            self.status = 'loginout'

    def get_uuid(self):
        url = 'https://login.weixin.qq.com/jslogin'
        params = {
            'appid': 'wx782c26e4c19acffb',
            'fun': 'new',
            'lang': 'zh_CN',
            '_': int(time.time()) * 1000 + random.randint(1, 999),
        }
        r = self.session.get(url, params=params)
        r.encoding = 'utf-8'
        data = r.text
        regx = r'window.QRLogin.code = (\d+); window.QRLogin.uuid = "(\S+?)"'
        pm = re.search(regx, data)
        if pm:
            code = pm.group(1)
            self.uuid = pm.group(2)
            return code == '200'
        return False

    def gen_qr_code(self, qr_file_path):
        string = 'https://login.weixin.qq.com/l/' + self.uuid
        qr = pyqrcode.create(string)
        if self.conf['qr'] == 'png':
            qr.png(qr_file_path, scale=8)
            show_image(qr_file_path)
            # img = Image.open(qr_file_path)
            # img.show()
        elif self.conf['qr'] == 'tty':
            print(qr.terminal(quiet_zone=1))

    def do_request(self, url):
        r = self.session.get(url)
        r.encoding = 'utf-8'
        data = r.text
        param = re.search(r'window.code=(\d+);', data)
        code = param.group(1)
        return code, data

    def wait4login(self):
        """
        http comet:
        tip=1, 等待用户扫描二维码,
               201: scaned
               408: timeout
        tip=0, 等待用户确认登录,
               200: confirmed
        """
        LOGIN_TEMPLATE = 'https://login.weixin.qq.com/cgi-bin/mmwebwx-bin/login?tip=%s&uuid=%s&_=%s'
        tip = 1

        try_later_secs = 1
        MAX_RETRY_TIMES = 10

        code = UNKONWN

        retry_time = MAX_RETRY_TIMES
        while retry_time > 0:
            url = LOGIN_TEMPLATE % (tip, self.uuid, int(time.time()))
            code, data = self.do_request(url)
            if code == SCANED:
                print '[INFO] Please confirm to login .'
                tip = 0
            elif code == SUCCESS:  # 确认登录成功
                param = re.search(r'window.redirect_uri="(\S+?)";', data)
                redirect_uri = param.group(1) + '&fun=new'
                self.redirect_uri = redirect_uri
                self.base_uri = redirect_uri[:redirect_uri.rfind('/')]
                temp_host = self.base_uri[8:]
                self.base_host = temp_host[:temp_host.find("/")]
                return code
            elif code == TIMEOUT:
                print '[ERROR] WeChat login timeout. retry in %s secs later...' % (try_later_secs,)

                tip = 1  # 重置
                retry_time -= 1
                time.sleep(try_later_secs)
            else:
                print ('[ERROR] WeChat login exception return_code=%s. retry in %s secs later...' %
                       (code, try_later_secs))
                tip = 1
                retry_time -= 1
                time.sleep(try_later_secs)

        return code

    def login(self):
        if len(self.redirect_uri) < 4:
            print '[ERROR] Login failed due to network problem, please try again.'
            return False
        r = self.session.get(self.redirect_uri)
        r.encoding = 'utf-8'
        data = r.text
        doc = xml.dom.minidom.parseString(data)
        root = doc.documentElement

        for node in root.childNodes:
            if node.nodeName == 'skey':
                self.skey = node.childNodes[0].data
            elif node.nodeName == 'wxsid':
                self.sid = node.childNodes[0].data
            elif node.nodeName == 'wxuin':
                self.uin = node.childNodes[0].data
            elif node.nodeName == 'pass_ticket':
                self.pass_ticket = node.childNodes[0].data

        if '' in (self.skey, self.sid, self.uin, self.pass_ticket):
            return False

        self.base_request = {
            'Uin': self.uin,
            'Sid': self.sid,
            'Skey': self.skey,
            'DeviceID': self.device_id,
        }
        return True

    def init(self):
        url = self.base_uri + '/webwxinit?r=%i&lang=en_US&pass_ticket=%s' % (int(time.time()), self.pass_ticket)
        params = {
            'BaseRequest': self.base_request
        }
        r = self.session.post(url, data=json.dumps(params))
        r.encoding = 'utf-8'
        dic = json.loads(r.text)
        self.sync_key = dic['SyncKey']
        self.my_account = dic['User']
        self.sync_key_str = '|'.join([str(keyVal['Key']) + '_' + str(keyVal['Val'])
                                      for keyVal in self.sync_key['List']])
        return dic['BaseResponse']['Ret'] == 0

    def status_notify(self):
        url = self.base_uri + '/webwxstatusnotify?lang=zh_CN&pass_ticket=%s' % self.pass_ticket
        self.base_request['Uin'] = int(self.base_request['Uin'])
        params = {
            'BaseRequest': self.base_request,
            "Code": 3,
            "FromUserName": self.my_account['UserName'],
            "ToUserName": self.my_account['UserName'],
            "ClientMsgId": int(time.time())
        }
        r = self.session.post(url, data=json.dumps(params))
        r.encoding = 'utf-8'
        dic = json.loads(r.text)
        return dic['BaseResponse']['Ret'] == 0

    def test_sync_check(self):
        for host1 in ['webpush.', 'webpush2.']:
            self.sync_host = host1 + self.base_host
            try:
                retcode = self.sync_check()[0]
            except:
                retcode = -1
            if retcode == '0':
                return True
        return False

    def sync_check(self):
        params = {
            'r': int(time.time()),
            'sid': self.sid,
            'uin': self.uin,
            'skey': self.skey,
            'deviceid': self.device_id,
            'synckey': self.sync_key_str,
            '_': int(time.time()),
        }
        url = 'https://' + self.sync_host + '/cgi-bin/mmwebwx-bin/synccheck?' + urllib.urlencode(params)
        try:
            r = self.session.get(url, timeout=60)
            r.encoding = 'utf-8'
            data = r.text
            pm = re.search(r'window.synccheck=\{retcode:"(\d+)",selector:"(\d+)"\}', data)
            retcode = pm.group(1)
            selector = pm.group(2)
            return [retcode, selector]
        except:
            return [-1, -1]

    def sync(self):
        url = self.base_uri + '/webwxsync?sid=%s&skey=%s&lang=en_US&pass_ticket=%s' \
                              % (self.sid, self.skey, self.pass_ticket)
        params = {
            'BaseRequest': self.base_request,
            'SyncKey': self.sync_key,
            'rr': ~int(time.time())
        }
        try:
            r = self.session.post(url, data=json.dumps(params), timeout=60)
            r.encoding = 'utf-8'
            dic = json.loads(r.text)
            if dic['BaseResponse']['Ret'] == 0:
                self.sync_key = dic['SyncCheckKey']
                self.sync_key_str = '|'.join([str(keyVal['Key']) + '_' + str(keyVal['Val'])
                                              for keyVal in self.sync_key['List']])
            return dic
        except:
            return None

    def get_icon(self, uid, gid=None):
        """
        获取联系人或者群聊成员头像
        :param uid: 联系人id
        :param gid: 群id，如果为非None获取群中成员头像，如果为None则获取联系人头像
        """
        if gid is None:
            url = self.base_uri + '/webwxgeticon?username=%s&skey=%s' % (uid, self.skey)
        else:
            url = self.base_uri + '/webwxgeticon?username=%s&skey=%s&chatroomid=%s' % (
                uid, self.skey, self.encry_chat_room_id_list[gid])
        r = self.session.get(url)
        data = r.content
        fn = 'icon_' + uid + '.jpg'
        with open(os.path.join(self.temp_pwd, fn), 'wb') as f:
            f.write(data)
        return fn

    def get_head_img(self, uid):
        """
        获取群头像
        :param uid: 群uid
        """
        url = self.base_uri + '/webwxgetheadimg?username=%s&skey=%s' % (uid, self.skey)
        r = self.session.get(url)
        data = r.content
        fn = 'head_' + uid + '.jpg'
        with open(os.path.join(self.temp_pwd, fn), 'wb') as f:
            f.write(data)
        return fn

    def get_msg_img_url(self, msgid):
        return self.base_uri + '/webwxgetmsgimg?MsgID=%s&skey=%s' % (msgid, self.skey)

    def get_msg_img(self, msgid):
        """
        获取图片消息，下载图片到本地
        :param msgid: 消息id
        :return: 保存的本地图片文件路径
        """
        url = self.base_uri + '/webwxgetmsgimg?MsgID=%s&skey=%s' % (msgid, self.skey)
        r = self.session.get(url)
        data = r.content
        fn = 'img_' + msgid + '.jpg'
        with open(os.path.join(self.temp_pwd, fn), 'wb') as f:
            f.write(data)
        return fn

    def get_voice_url(self, msgid):
        return self.base_uri + '/webwxgetvoice?msgid=%s&skey=%s' % (msgid, self.skey)

    def get_voice(self, msgid):
        """
        获取语音消息，下载语音到本地
        :param msgid: 语音消息id
        :return: 保存的本地语音文件路径
        """
        url = self.base_uri + '/webwxgetvoice?msgid=%s&skey=%s' % (msgid, self.skey)
        r = self.session.get(url)
        data = r.content
        fn = 'voice_' + msgid + '.mp3'
        with open(os.path.join(self.temp_pwd, fn), 'wb') as f:
            f.write(data)
        return fn

    def get_video_url(self, msgid):
        return self.base_uri + '/webwxgetvideo?msgid=%s&skey=%s' % (msgid, self.skey)

    def get_video(self, msgid):
        """
        获取视频消息，下载视频到本地
        :param msgid: 视频消息id
        :return: 保存的本地视频文件路径
        """
        url = self.base_uri + '/webwxgetvideo?msgid=%s&skey=%s' % (msgid, self.skey)
        headers = {'Range': 'bytes=0-'}
        r = self.session.get(url, headers=headers)
        data = r.content
        fn = 'video_' + msgid + '.mp4'
        with open(os.path.join(self.temp_pwd, fn), 'wb') as f:
            f.write(data)
        return fn

    def set_remarkname(self, uid, remarkname):  # 设置联系人的备注名
        url = self.base_uri + '/webwxoplog?lang=zh_CN&pass_ticket=%s' \
                              % (self.pass_ticket)
        remarkname = self.to_unicode(remarkname)
        params = {
            'BaseRequest': self.base_request,
            'CmdId': 2,
            'RemarkName': remarkname,
            'UserName': uid
        }
        try:
            r = self.session.post(url, data=json.dumps(params), timeout=60)
            r.encoding = 'utf-8'
            dic = json.loads(r.text)
            return dic['BaseResponse']['ErrMsg']
        except:
            return None
